package com.velnora.app

import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/** Real measurements only. UDP servers have no handshake we can time, so they are tried with a normal echo. */
object Ping {
    /** Milliseconds, or null when the server did not answer. Call it away from the main thread. */
    fun measure(host: String, port: Int, proto: String): Long? = try {
        val t0 = System.nanoTime()
        if (proto.startsWith("tcp")) {
            Socket().use { it.connect(InetSocketAddress(host, port), 3000) }
            (System.nanoTime() - t0) / 1_000_000
        } else {
            if (InetAddress.getByName(host).isReachable(2500)) (System.nanoTime() - t0) / 1_000_000 else null
        }
    } catch (e: Exception) {
        null
    }
}
