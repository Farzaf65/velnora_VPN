package com.velnora.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Watches the phone's real internet (not the VPN itself) to reconnect after a change. */
object NetWatch {
    private var cb: ConnectivityManager.NetworkCallback? = null
    private var cur: Network? = null

    fun start(ctx: Context) {
        if (cb != null) return
        try {
            val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val req = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                .build()
            val c = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    val prev = cur
                    cur = network
                    when {
                        prev == null -> VpnCtl.networkBack()
                        prev != network -> VpnCtl.networkChanged()
                    }
                }

                override fun onLost(network: Network) {
                    if (cur == network) {
                        cur = null
                        VpnCtl.networkLost()
                    }
                }
            }
            cm.registerNetworkCallback(req, c)
            cb = c
        } catch (e: Exception) {
        }
    }
}

/** The status notification: connection time and the speeds the engine reports. */
object Notifier {
    private const val CH = "velnora_conn"
    private const val ID = 7001
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var app: Context? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH, "وضعیت اتصال", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        scope.launch { VpnCtl.state.collect { onState(it) } }
    }

    private fun onState(s: VState) {
        val c = app ?: return
        job?.cancel()
        if (s == VState.Off || s == VState.Failed || !Prefs(c).b("notif", true)) {
            cancel(c)
            return
        }
        job = scope.launch {
            while (true) {
                post(c, s)
                delay(2000)
            }
        }
    }

    private fun cancel(c: Context) {
        try {
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID)
        } catch (e: Exception) {
        }
    }

    private fun post(c: Context, s: VState) {
        try {
            val text = if (s == VState.Connecting) {
                "در حال اتصال…"
            } else {
                val since = VpnCtl.since.value
                val t = if (since > 0) ((System.currentTimeMillis() - since) / 1000).coerceAtLeast(0) else 0
                val dur = fa("%02d:%02d:%02d".format(t / 3600, (t % 3600) / 60, t % 60))
                "مدت $dur · ↓ " + fmtSpeed(VpnCtl.down.value) + " · ↑ " + fmtSpeed(VpnCtl.up.value)
            }
            val pi = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(c, CH)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle(if (s == VState.On) "ولنورا · وصل" else "ولنورا")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi)
                .build()
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID, n)
        } catch (e: SecurityException) {
        } catch (e: Exception) {
        }
    }
}

/** The launcher icon is chosen by enabling one of the aliases in the manifest. */
object AppIcon {
    val NAMES = listOf("بنفش ولنورا", "آبی", "زمردی", "گل‌سرخ", "کهربایی")
    val PREVIEWS = listOf(R.drawable.icp_0, R.drawable.icp_1, R.drawable.icp_2, R.drawable.icp_3, R.drawable.icp_4)

    private fun cn(ctx: Context, i: Int) = ComponentName(ctx.packageName, "com.velnora.app.Icon$i")

    fun current(ctx: Context): Int {
        for (i in NAMES.indices) {
            val st = ctx.packageManager.getComponentEnabledSetting(cn(ctx, i))
            if (st == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) return i
        }
        return 0
    }

    /** The new icon is enabled first so the app never disappears from the launcher. */
    fun set(ctx: Context, idx: Int) {
        try {
            val pm = ctx.packageManager
            pm.setComponentEnabledSetting(cn(ctx, idx), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            for (i in NAMES.indices) {
                if (i != idx) {
                    pm.setComponentEnabledSetting(cn(ctx, i), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                }
            }
        } catch (e: Exception) {
        }
    }

    /** Closes the app a moment later so the launcher picks the new icon up. */
    fun closeApp(ctx: Context) {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
        val a = c as? android.app.Activity ?: return
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                a.finishAndRemoveTask()
            } catch (e: Exception) {
                a.finishAffinity()
            }
        }, 1400)
    }
}
