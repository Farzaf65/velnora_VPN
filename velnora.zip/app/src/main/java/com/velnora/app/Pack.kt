package com.velnora.app

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/** Reads ZIP files that hold .ovpn/.conf configs together with their certificate files. */
object Pack {
    fun isZip(b: ByteArray): Boolean = b.size > 4 && b[0] == 0x50.toByte() && b[1] == 0x4B.toByte()

    private fun base(n: String): String = n.substringAfterLast('/').substringAfterLast('\\').lowercase()

    /** Returns (name, config text) for every valid config in the ZIP. */
    fun fromZip(bytes: ByteArray): List<Pair<String, String>> {
        val files = LinkedHashMap<String, ByteArray>()
        var total = 0L
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory || files.size >= 300) continue
                val data = z.readBytes()
                total += data.size
                if (total > 30_000_000L) break
                files[e.name] = data
            }
        }
        val out = ArrayList<Pair<String, String>>()
        for ((n, d) in files) {
            val l = n.lowercase()
            if (!(l.endsWith(".ovpn") || l.endsWith(".conf"))) continue
            val text = String(d, Charsets.UTF_8)
            if (!Ovpn.looksLike(text)) continue
            out.add(base(n).removeSuffix(".ovpn").removeSuffix(".conf") to inline(text, files))
        }
        return out
    }

    private fun find(files: Map<String, ByteArray>, ref: String): String? {
        val want = base(ref)
        for ((n, d) in files) if (base(n) == want) return String(d, Charsets.UTF_8).trim()
        return null
    }

    /** Puts files named in the config (ca, cert, key, tls-auth, tls-crypt) inside it. */
    fun inline(text: String, files: Map<String, ByteArray>): String {
        val tags = mapOf(
            "ca" to "ca", "cert" to "cert", "key" to "key", "dh" to "dh",
            "extra-certs" to "extra-certs", "tls-auth" to "tls-auth", "tls-crypt" to "tls-crypt",
            "tls-crypt-v2" to "tls-crypt-v2"
        )
        val sb = StringBuilder()
        val blocks = StringBuilder()
        for (line in text.lines()) {
            val p = line.trim().split(Regex("\\s+"))
            val tag = if (p.isNotEmpty()) tags[p[0].lowercase()] else null
            if (tag != null && p.size >= 2 && !line.trim().startsWith("#") && !line.trim().startsWith(";")) {
                val content = find(files, p[1].trim('"', '\''))
                if (content != null) {
                    blocks.append("<").append(tag).append(">\n").append(content).append("\n</").append(tag).append(">\n")
                    if (tag == "tls-auth" && p.size >= 3) sb.append("key-direction ").append(p[2]).append("\n")
                    continue
                }
            }
            sb.append(line).append("\n")
        }
        return sb.toString().trimEnd() + "\n" + blocks.toString()
    }
}
