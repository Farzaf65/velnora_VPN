package com.velnora.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("velnora", Context.MODE_PRIVATE)
    fun s(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun put(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun l(k: String, d: Long = 0L): Long = sp.getLong(k, d)
    fun putL(k: String, v: Long) = sp.edit().putLong(k, v).apply()
    fun b(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun putB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    fun i(k: String, d: Int = 0): Int = sp.getInt(k, d)
    fun putI(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    fun set(k: String): Set<String> = (sp.getStringSet(k, emptySet()) ?: emptySet()).toSet()
    fun putSet(k: String, v: Set<String>) = sp.edit().putStringSet(k, HashSet(v)).apply()
}

class Conf(
    val id: String,
    val name: String,
    val host: String,
    val port: String,
    val proto: String,
    val needsAuth: Boolean,
    val keyEnc: Boolean,
    val expiresAt: Long?,
    val subId: String?,
    val cipher: String = "",
    val authAlg: String = "",
    val tls: String = "",
    val remotes: Int = 1
)

class Subscr(
    val id: String,
    val url: String,
    val title: String,
    val used: Long,
    val total: Long,
    val expire: Long,
    val at: Long
)

/** Config texts, passwords and subscription links are kept in encrypted storage. */
class ConfStore(ctx: Context) {
    private val sp: SharedPreferences = try {
        val mk = MasterKey.Builder(ctx.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx.applicationContext, "velnora_cfg", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Throwable) {
        ctx.applicationContext.getSharedPreferences("velnora_cfg_plain", Context.MODE_PRIVATE)
    }

    private fun ids(): List<String> = (sp.getString("ids", "") ?: "").split("\n").filter { it.isNotBlank() }
    private fun saveIds(l: List<String>) = sp.edit().putString("ids", l.joinToString("\n")).apply()

    fun list(): List<Conf> = ids().mapNotNull { get(it) }

    fun get(id: String): Conf? {
        val t = sp.getString("t:$id", null) ?: return null
        val i = Ovpn.parse(t) ?: return null
        val x = sp.getLong("x:$id", 0L)
        val s = sp.getString("s:$id", "") ?: ""
        return Conf(
            id, sp.getString("n:$id", i.host) ?: i.host, i.host, i.port, i.proto, i.needsAuth, i.keyEncrypted,
            if (x > 0) x else i.expiresAt, s.ifBlank { null }, i.cipher, i.authAlg, i.tls, i.remotes
        )
    }

    fun text(id: String): String = sp.getString("t:$id", "") ?: ""

    fun add(name: String, text: String, subId: String? = null, expireMs: Long = 0L): Conf? {
        val info = Ovpn.parse(text) ?: return null
        val id = UUID.randomUUID().toString()
        sp.edit()
            .putString("t:$id", text)
            .putString("n:$id", name.ifBlank { info.host })
            .putString("s:$id", subId ?: "")
            .putLong("x:$id", expireMs)
            .apply()
        saveIds(ids() + id)
        return get(id)
    }

    fun remove(id: String) {
        sp.edit().remove("t:$id").remove("n:$id").remove("s:$id").remove("x:$id")
            .remove("u:$id").remove("p:$id").remove("k:$id").apply()
        saveIds(ids().filter { it != id })
    }

    fun removeBySub(subId: String) {
        for (c in list()) if (c.subId == subId) remove(c.id)
    }

    fun creds(id: String): Pair<String, String>? {
        val u = sp.getString("u:$id", null) ?: return null
        return u to (sp.getString("p:$id", "") ?: "")
    }

    fun saveCreds(id: String, u: String, p: String) {
        sp.edit().putString("u:$id", u).putString("p:$id", p).apply()
    }

    fun keyPass(id: String): String? = sp.getString("k:$id", null)
    fun saveKeyPass(id: String, p: String) = sp.edit().putString("k:$id", p).apply()

    fun hasSaved(id: String): Boolean = sp.contains("u:$id") || sp.contains("k:$id")
    fun clearSaved(id: String) = sp.edit().remove("u:$id").remove("p:$id").remove("k:$id").apply()

    fun subs(): List<Subscr> {
        val out = ArrayList<Subscr>()
        try {
            val a = JSONArray(sp.getString("subs", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Subscr(
                        o.getString("id"), o.getString("url"), o.optString("title"),
                        o.optLong("used", -1), o.optLong("total", -1), o.optLong("expire", -1), o.optLong("at", 0)
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveSubs(l: List<Subscr>) {
        val a = JSONArray()
        for (s in l) {
            a.put(
                JSONObject().put("id", s.id).put("url", s.url).put("title", s.title)
                    .put("used", s.used).put("total", s.total).put("expire", s.expire).put("at", s.at)
            )
        }
        sp.edit().putString("subs", a.toString()).apply()
    }

    private fun key(c: Conf) = c.host + "|" + c.port + "|" + c.proto

    fun rename(id: String, name: String) {
        if (sp.contains("t:$id") && name.isNotBlank()) sp.edit().putString("n:$id", name.trim()).apply()
    }

    fun sub(id: String?): Subscr? = if (id == null) null else subs().firstOrNull { it.id == id }

    /**
     * Adds a subscription (or refreshes the one with the same link). Servers that are still listed
     * keep their id, saved passwords and name; new ones are added, ones no longer listed are removed.
     * Returns the subscription, how many are new and how many were removed.
     */
    fun applySub(url: String, d: SubData): Triple<Subscr, Int, Int> {
        val old = subs().firstOrNull { it.url == url.trim() }
        val id = old?.id ?: UUID.randomUUID().toString()
        val exp = if (d.expire > 0) d.expire * 1000L else 0L
        val existing = list().filter { it.subId == id }.associateBy { key(it) }.toMutableMap()
        var added = 0
        for ((name, text) in d.configs) {
            val info = Ovpn.parse(text) ?: continue
            val k = info.host + "|" + info.port + "|" + info.proto
            val hit = existing.remove(k)
            if (hit != null) {
                sp.edit().putString("t:" + hit.id, text).putLong("x:" + hit.id, exp).apply()
            } else if (add(name, text, id, exp) != null) {
                added++
            }
        }
        val gone = existing.size
        for (c in existing.values) remove(c.id)
        val s = Subscr(
            id, url.trim(), d.title.ifBlank { old?.title ?: "" }, d.used, d.total, d.expire, System.currentTimeMillis()
        )
        saveSubs(subs().filter { it.id != id } + s)
        return Triple(s, added, gone)
    }

    fun removeSub(id: String) {
        removeBySub(id)
        saveSubs(subs().filter { it.id != id })
    }
}
