package com.velnora.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object Incoming {
    val uri = mutableStateOf<Uri?>(null)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        take(intent)
        setContent { App() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        take(intent)
    }

    private fun take(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_VIEW) {
            Incoming.uri.value = i.data
        }
    }
}

/** Reads a file: a ZIP gives every config inside it, anything else is one text. */
private fun readUri(ctx: Context, uri: Uri): List<Pair<String, String>>? = try {
    var name = ""
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: ""
    }
    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
    when {
        bytes == null || bytes.size > 30_000_000 -> null
        Pack.isZip(bytes) -> Pack.fromZip(bytes)
        else -> listOf(name.removeSuffix(".ovpn").removeSuffix(".conf") to String(bytes, Charsets.UTF_8))
    }
} catch (e: Exception) {
    null
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { ConfStore(ctx) }
    val prefs = remember { Prefs(ctx) }
    val scope = rememberCoroutineScope()

    var confs by remember { mutableStateOf(store.list()) }
    var subs by remember { mutableStateOf(store.subs()) }
    var sel by remember { mutableStateOf<String?>(prefs.s("sel").ifBlank { null }) }
    var splash by remember { mutableStateOf(true) }
    var confirm by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var imported by remember { mutableStateOf<String?>(null) }
    var over by remember { mutableStateOf(0) }
    var addOpen by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<Conf?>(null) }
    var menu by remember { mutableStateOf(false) }
    var authFor by remember { mutableStateOf<Conf?>(null) }
    var keyFor by remember { mutableStateOf<Conf?>(null) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var pings by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }
    var measuring by remember { mutableStateOf(false) }
    var auto by remember { mutableStateOf(prefs.b("auto", true)) }
    var lastT by remember { mutableStateOf(prefs.l("last_t")) }
    var lastOk by remember { mutableStateOf(prefs.b("last_ok", false)) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }

    val st by VpnCtl.state.collectAsState()
    val note by VpnCtl.note.collectAsState()
    val since by VpnCtl.since.collectAsState()
    val down by VpnCtl.down.collectAsState()
    val up by VpnCtl.up.collectAsState()
    val logs by VpnCtl.logs.collectAsState()

    fun refresh() {
        confs = store.list()
        subs = store.subs()
        if (sel != null && confs.none { it.id == sel }) sel = null
        if (sel == null) sel = confs.firstOrNull()?.id
        prefs.put("sel", sel ?: "")
    }

    fun addSub(url: String, silent: Boolean = false, onOk: (() -> Unit)? = null) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                val d = withContext(Dispatchers.IO) { Sub.fetch(url) }
                val r = store.applySub(url, d)
                refresh()
                onOk?.invoke()
                if (!silent) {
                    msg = (if (r.second > 0) fa(r.second.toLong()) + " سرور جدید" else "بروز شد") +
                        (if (r.third > 0) " · " + fa(r.third.toLong()) + " سرور حذف‌شده" else "")
                }
            } catch (e: Exception) {
                if (!silent) {
                    val m = e.message ?: ""
                    msg = when {
                        m == "format" -> "فرمت این لینک پشتیبانی نمی‌شه"
                        m == "auth" -> "این لینک احراز هویت می‌خواد (نام کاربری و رمز رو داخل لینک بنویس)"
                        m.startsWith("HTTP") -> "سرور لینک جواب نداد (" + m + ")"
                        else -> "دریافت لینک انجام نشد؛ اینترنت و لینک رو چک کن"
                    }
                }
            }
            busy = false
        }
    }

    /** Adds the configs; one new profile opens the "imported" page, several go to the list. */
    fun addTexts(items: List<Pair<String, String>>) {
        val ids = ArrayList<String>()
        var link = false
        for ((name, text) in items) {
            if (Sub.isLink(text)) {
                link = true
                addSub(text.trim(), onOk = { over = 0 })
                continue
            }
            val parts = Sub.split(text)
            for ((i, p) in parts.withIndex()) {
                val c = store.add(if (parts.size > 1 && name.isNotBlank()) name + " " + (i + 1) else name, p)
                if (c != null) {
                    ids.add(c.id)
                    if (sel == null) sel = c.id
                }
            }
        }
        refresh()
        if (ids.size == 1) {
            imported = ids[0]
            over = 10
        } else if (ids.size > 1) {
            over = 0
            msg = fa(ids.size.toLong()) + " پروفایل اضافه شد"
        } else if (!link) {
            msg = "کانفیگ OpenVPN معتبری پیدا نشد"
        }
    }

    /** Pasted text or a link from the "Get connected" page. */
    fun next(t: String) {
        when {
            Sub.isLink(t) -> addSub(t, onOk = { over = 0 })
            Ovpn.looksLike(t) || Sub.split(t).isNotEmpty() -> {
                confirm = listOf("پروفایل" to t)
            }
            else -> msg = "فرمت شناخته نشد؛ لینک اشتراک یا متن کانفیگ OpenVPN بده"
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val r = withContext(Dispatchers.IO) { readUri(ctx, uri) }
                if (r == null || r.isEmpty()) msg = "فایل خونده نشد یا کانفیگی توش نیست" else confirm = r
            }
        }
    }

    val vpnPerm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val p = pending
        pending = null
        if (r.resultCode == android.app.Activity.RESULT_OK) p?.invoke() else VpnCtl.fail("مجوز VPN داده نشد")
    }

    val inc = Incoming.uri.value
    LaunchedEffect(inc) {
        if (inc != null) {
            Incoming.uri.value = null
            val r = withContext(Dispatchers.IO) { readUri(ctx, inc) }
            if (r == null || r.isEmpty()) msg = "فایل خونده نشد یا کانفیگی توش نیست" else confirm = r
        }
    }

    // Refresh stale subscriptions once when the app opens.
    LaunchedEffect(Unit) {
        if (auto) {
            for (s in store.subs()) {
                if (System.currentTimeMillis() - s.at > 12 * 3600_000L) {
                    try {
                        val d = withContext(Dispatchers.IO) { Sub.fetch(s.url) }
                        store.applySub(s.url, d)
                    } catch (e: Exception) {
                    }
                }
            }
            refresh()
        }
    }

    // Remember how the last attempt ended.
    LaunchedEffect(st) {
        if (st == VState.On || st == VState.Failed) {
            lastT = System.currentTimeMillis()
            lastOk = st == VState.On
            prefs.putL("last_t", lastT)
            prefs.putB("last_ok", lastOk)
        }
    }

    val pick = { id: String -> sel = id; prefs.put("sel", id) }

    fun measureAll(after: ((Map<String, Long>) -> Unit)? = null) {
        if (measuring) return
        if (confs.isEmpty()) {
            msg = "سروری برای سنجش نیست"
            return
        }
        measuring = true
        scope.launch {
            val list = confs
            val res = HashMap<String, Long>()
            for (chunk in list.chunked(6)) {
                val r = withContext(Dispatchers.IO) {
                    chunk.map { c ->
                        async { Pair(c.id, Ping.measure(c.host, c.port.toIntOrNull() ?: 1194, c.proto) ?: -1L) }
                    }.map { d -> d.await() }
                }
                for ((id, v) in r) res[id] = v
                pings = pings + res
            }
            measuring = false
            after?.invoke(pings)
        }
    }

    fun fastest() {
        measureAll { p ->
            val best = confs.filter { (p[it.id] ?: -1L) >= 0L }.minByOrNull { p[it.id] ?: Long.MAX_VALUE }
            if (best == null) {
                msg = "هیچ سروری به پینگ جواب نداد (پینگ UDP معمولاً قابل اندازه‌گیری نیست)"
            } else {
                pick(best.id)
                msg = "سریع‌ترین: " + Privacy.name(best.name) + " (" + fa(p[best.id] ?: 0L) + " ms)"
            }
        }
    }

    fun start(c: Conf, user: String?, pass: String?, key: String?) {
        val req = Req(c.name, Ovpn.withProto(store.text(c.id), Opts.proto(prefs)), user, pass, key, Opts.load(prefs))
        val run = { VpnCtl.connect(ctx, req) }
        if (!VpnCtl.engine.ready) {
            run()
            return
        }
        val i = VpnService.prepare(ctx)
        if (i != null) {
            pending = run
            vpnPerm.launch(i)
        } else {
            run()
        }
    }

    fun connect() {
        if (st == VState.On || st == VState.Connecting) {
            VpnCtl.disconnect(ctx)
            return
        }
        val c = confs.firstOrNull { it.id == sel }
        if (c == null) {
            msg = "اول یه سرور اضافه یا انتخاب کن"
            return
        }
        if (c.needsAuth && store.creds(c.id) == null) {
            authFor = c
            return
        }
        if (c.keyEnc && store.keyPass(c.id) == null) {
            keyFor = c
            return
        }
        val cr = store.creds(c.id)
        start(c, cr?.first, cr?.second, store.keyPass(c.id))
    }

    LaunchedEffect(msg) {
        if (msg != null) {
            delay(3500)
            msg = null
        }
    }
    BackHandler(enabled = menu || confirm != null || over != 0) {
        when {
            menu -> menu = false
            confirm != null -> confirm = null
            over == 8 -> over = 3
            over == 10 -> over = 0
            else -> over = 0
        }
    }

    // Ask once for the notification permission (Android 13+), long before any VPN prompt.
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !prefs.b("asked_notif", false)) {
            prefs.putB("asked_notif", true)
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                delay(1200)
                notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val menuItems = remember {
        listOf(
            MenuItem(0, "dns", "پروفایل‌ها", "فهرست سرورها و اتصال"),
            MenuItem(9, "plus", "افزودن پروفایل", "لینک یا فایل .ovpn"),
            MenuItem(2, "link", "اشتراک‌ها", "بروزرسانی لینک‌ها"),
            MenuItem(3, "gear", "تنظیمات", "پروتکل، DNS، تونل جداگانه"),
            MenuItem(4, "log", "لاگ اتصال", "رویدادهای واقعی اتصال"),
            MenuItem(6, "palette", "ظاهر و آیکون", "رنگ و آیکون برنامه"),
            MenuItem(5, "chat", "ارتباط با ما", "پشتیبانی و کانال")
        )
    }

    val curSub = subs.firstOrNull { s -> s.id == confs.firstOrNull { it.id == sel }?.subId }
    val last = if (lastT > 0) (if (lastOk) "موفق" else "ناموفق") + " · " + fmtAgo(lastT) else null
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(Modifier.fillMaxSize().background(C.bg)) {
            val dd = detail
            val imp = imported?.let { store.get(it) }
            when {
                over == 2 -> SubsScreen(
                    subs, busy,
                    onBack = { over = 0 },
                    onAdd = { addOpen = true },
                    onUpdate = { addSub(it.url) },
                    onDelete = { store.removeSub(it.id); refresh() }
                )
                over == 3 -> SettingsScreen(
                    prefs, auto,
                    onAuto = { auto = it; prefs.putB("auto", it); Updater.schedule(ctx, it) },
                    onBack = { over = 0 },
                    onSubs = { over = 2 },
                    onApps = { over = 8 }
                )
                over == 8 -> AppsScreen(prefs) { over = 3 }
                over == 4 -> LogScreen(
                    logs,
                    onBack = { over = 0 },
                    onCopy = {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("velnora-log", logs.joinToString("\n")))
                        msg = "لاگ کپی شد"
                    },
                    onClear = { VpnCtl.clearLog() }
                )
                over == 5 -> ContactScreen({ over = 0 }) { msg = it }
                over == 6 -> AppearanceScreen(prefs, { over = 0 }) { idx ->
                    AppIcon.set(ctx, idx)
                    msg = "آیکون عوض شد؛ برنامه بسته می‌شه"
                    AppIcon.closeApp(ctx)
                }
                over == 7 && dd != null -> DetailScreen(
                    dd, store.sub(dd.subId), store.hasSaved(dd.id), pings[dd.id], dd.id == sel,
                    onBack = { over = 0 },
                    onConnect = {
                        pick(dd.id)
                        over = 0
                        if (st == VState.Off || st == VState.Failed) {
                            connect()
                        } else {
                            msg = "اول اتصال فعلی رو قطع کن"
                        }
                    },
                    onPing = {
                        scope.launch {
                            val v = withContext(Dispatchers.IO) { Ping.measure(dd.host, dd.port.toIntOrNull() ?: 1194, dd.proto) ?: -1L }
                            pings = pings + (dd.id to v)
                        }
                    },
                    onForget = { store.clearSaved(dd.id); msg = "رمزهای ذخیره‌شده پاک شد"; detail = store.get(dd.id) },
                    onDelete = { store.remove(dd.id); detail = null; over = 0; refresh() },
                    onSave = { n, u, p ->
                        store.rename(dd.id, n)
                        if (u.isNotBlank()) store.saveCreds(dd.id, u, if (p.isNotEmpty()) p else (store.creds(dd.id)?.second ?: ""))
                        over = 0
                        refresh()
                        msg = "ذخیره شد"
                    }
                )
                over == 9 || (over == 0 && confs.isEmpty()) -> GetConnectedScreen(
                    busy, canLeave = confs.isNotEmpty(),
                    onMenu = { menu = true },
                    onBack = { over = 0 },
                    onNext = { next(it) },
                    onBrowse = { picker.launch(arrayOf("*/*")) }
                )
                over == 10 && imp != null -> ImportedScreen(
                    imp,
                    onBack = { over = 0 },
                    onProfiles = { n -> store.rename(imp.id, n); refresh(); over = 0 },
                    onConnect = { n ->
                        store.rename(imp.id, n)
                        refresh()
                        pick(imp.id)
                        over = 0
                        if (st == VState.Off || st == VState.Failed) connect() else msg = "اول اتصال فعلی رو قطع کن"
                    }
                )
                else -> ProfilesScreen(
                    confs, sel, st, note, since, down, up, curSub, last, pings, measuring,
                    onToggle = { c ->
                        if (c.id == sel && (st == VState.On || st == VState.Connecting)) {
                            VpnCtl.disconnect(ctx)
                        } else if (st == VState.On || st == VState.Connecting) {
                            msg = "اول اتصال فعلی رو قطع کن"
                        } else {
                            pick(c.id)
                            connect()
                        }
                    },
                    onEdit = { detail = it; over = 7 },
                    onAdd = { over = 9 },
                    onMenu = { menu = true },
                    onLog = { over = 4 },
                    onFastest = { fastest() },
                    onPing = { measureAll() }
                )
            }
            Drawer(menu, menuItems, onPick = { id -> menu = false; over = id }, onClose = { menu = false })

            val cf = confirm
            if (cf != null) {
                ConfirmImport(
                    cf,
                    onOk = { confirm = null; addTexts(cf) },
                    onCancel = { confirm = null }
                )
            }
            if (splash) SplashScreen { splash = false }

            if (addOpen) {
                AddSheet(
                    onDismiss = { addOpen = false },
                    onFile = { addOpen = false; picker.launch(arrayOf("*/*")) },
                    onText = { addOpen = false; addTexts(listOf("" to it)) }
                )
            }
            val a = authFor
            if (a != null) {
                AuthSheet(a.name, onDismiss = { authFor = null }) { u, p, keep ->
                    authFor = null
                    if (keep) store.saveCreds(a.id, u, p)
                    if (a.keyEnc && store.keyPass(a.id) == null) {
                        keyFor = a
                    } else {
                        start(a, u, p, store.keyPass(a.id))
                    }
                }
            }
            val k = keyFor
            if (k != null) {
                KeySheet(k.name, onDismiss = { keyFor = null }) { p, keep ->
                    keyFor = null
                    if (keep) store.saveKeyPass(k.id, p)
                    val cr = store.creds(k.id)
                    start(k, cr?.first, cr?.second, p)
                }
            }
            val m = msg
            if (m != null) {
                Box(
                    Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(20.dp)
                        .background(C.surf2, RoundedCornerShape(16.dp)).border(1.dp, C.line, RoundedCornerShape(16.dp))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) { Text(m, color = C.fg, fontSize = 13.sp) }
            }
        }
    }
}
