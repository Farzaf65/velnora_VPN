package com.velnora.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class VState { Off, Connecting, On, Failed }

/** The part that really opens the tunnel. The OpenVPN engine plugs in here. */
interface Engine {
    val ready: Boolean

    /** True when the engine itself reconnects after a network change. */
    val selfReconnect: Boolean get() = false
    fun init(ctx: Context) {}
    fun start(ctx: Context, name: String, text: String, user: String?, pass: String?, keyPass: String?, opts: ConnOpts)
    fun stop(ctx: Context)
}

object NoEngine : Engine {
    override val ready = false
    override fun start(
        ctx: Context, name: String, text: String, user: String?, pass: String?, keyPass: String?, opts: ConnOpts
    ) {
        VpnCtl.fail("موتور OpenVPN در این نسخه فعال نیست")
    }

    override fun stop(ctx: Context) {
        VpnCtl.off()
    }
}

/** Looks for the real engine class (it exists only when the app is built with the engine). */
object EngineLoader {
    fun load(ctx: Context) {
        VpnCtl.init(ctx)
        try {
            val e = Class.forName("com.velnora.app.OvpnEngine").getDeclaredConstructor().newInstance() as Engine
            e.init(ctx.applicationContext)
            VpnCtl.engine = e
            VpnCtl.log("موتور OpenVPN بارگذاری شد")
        } catch (t: Throwable) {
            VpnCtl.engine = NoEngine
            VpnCtl.log("موتور OpenVPN در این نسخه نیست؛ فقط رابط کاربری فعاله")
        }
    }
}

/** The last request, kept so the app can reconnect by itself. */
class Req(
    val name: String, val text: String, val user: String?, val pass: String?, val key: String?, val opts: ConnOpts
)

/** Only values reported by the engine are shown; nothing here is invented. */
object VpnCtl {
    val state = MutableStateFlow(VState.Off)
    val note = MutableStateFlow("")
    val since = MutableStateFlow(0L)

    /** Bytes per second, -1 = unknown. */
    val down = MutableStateFlow(-1L)
    val up = MutableStateFlow(-1L)
    val logs = MutableStateFlow<List<String>>(emptyList())
    var engine: Engine = NoEngine

    private var app: Context? = null
    private var last: Req? = null
    private var wanted = false
    private var tries = 0
    private var lastRetry = 0L
    private val main = Handler(Looper.getMainLooper())
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun init(ctx: Context) {
        app = ctx.applicationContext
    }

    /** Adds one line to the connection log (kept in memory, newest last, at most 400 lines). */
    fun log(msg: String) {
        val line = clock.format(Date()) + "  " + msg
        val l = logs.value
        logs.value = (if (l.size >= 400) l.drop(l.size - 399) else l) + line
    }

    fun clearLog() {
        logs.value = emptyList()
    }

    fun connect(ctx: Context, r: Req) {
        last = r
        wanted = true
        tries = 0
        run(ctx, r)
    }

    private fun run(ctx: Context, r: Req) {
        note.value = ""
        state.value = VState.Connecting
        log("اتصال به «" + r.name + "» شروع شد")
        engine.start(ctx, r.name, r.text, r.user, r.pass, r.key, r.opts)
    }

    fun disconnect(ctx: Context) {
        wanted = false
        log("قطع اتصال توسط کاربر")
        engine.stop(ctx)
    }

    fun connected() {
        if (state.value != VState.On) {
            since.value = System.currentTimeMillis()
            log("تونل برقرار شد")
        }
        tries = 0
        state.value = VState.On
    }

    fun connecting() {
        state.value = VState.Connecting
    }

    fun off() {
        val was = state.value
        since.value = 0L
        down.value = -1L
        up.value = -1L
        state.value = VState.Off
        if (was == VState.On) log("اتصال قطع شد")
        if (wanted && was == VState.On) retry("اتصال ناگهانی قطع شد")
    }

    fun fail(msg: String) {
        since.value = 0L
        down.value = -1L
        up.value = -1L
        note.value = msg
        state.value = VState.Failed
        log("خطا: $msg")
    }

    fun speed(d: Long, u: Long) {
        down.value = d
        up.value = u
    }

    // ---- automatic reconnect -------------------------------------------------

    private fun auto(): Boolean {
        val c = app ?: return false
        return Prefs(c).b("reconnect", true) && wanted && last != null && engine.ready
    }

    private fun retry(why: String) {
        if (!auto()) return
        val now = System.currentTimeMillis()
        if (now - lastRetry < 4000 || tries >= 4) return
        lastRetry = now
        tries++
        log("$why؛ تلاش دوباره (" + tries + ")")
        val r = last ?: return
        val c = app ?: return
        main.postDelayed({ if (wanted && state.value != VState.On && state.value != VState.Connecting) run(c, r) }, 2500)
    }

    /** Called when the phone's own internet changes (Wi-Fi to mobile data and back). */
    fun networkChanged() {
        log("شبکه‌ی اینترنت عوض شد")
        if (!auto()) return
        val c = app ?: return
        val r = last ?: return
        when (state.value) {
            VState.On -> if (!engine.selfReconnect) {
                log("اتصال دوباره روی شبکه‌ی جدید")
                engine.stop(c)
                main.postDelayed({ if (wanted) run(c, r) }, 2500)
            }
            VState.Failed, VState.Off -> retry("اینترنت برگشت")
            VState.Connecting -> {}
        }
    }

    fun networkBack() {
        log("اینترنت وصل شد")
        if (state.value == VState.Failed || state.value == VState.Off) retry("اینترنت برگشت")
    }

    fun networkLost() {
        log("اینترنت قطع شد")
    }
}
