package com.velnora.app

/** What the user chose in Settings that the engine must obey for one connection. */
class ConnOpts(
    val dns1: String = "",
    val dns2: String = "",
    /** 0 = all apps use the VPN, 1 = only the chosen apps, 2 = all apps except the chosen ones. */
    val splitMode: Int = 0,
    val splitApps: Set<String> = emptySet()
)

object Opts {
    private val ip4 = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$")

    fun validIp(s: String): Boolean {
        val m = ip4.matchEntire(s.trim()) ?: return false
        return m.groupValues.drop(1).all { it.toInt() in 0..255 }
    }

    /** "auto", "udp" or "tcp". */
    fun proto(p: Prefs): String = p.s("proto", "auto")

    fun load(p: Prefs): ConnOpts {
        val d1 = p.s("dns1").trim().let { if (validIp(it)) it else "" }
        val d2 = p.s("dns2").trim().let { if (validIp(it)) it else "" }
        return ConnOpts(d1, d2, p.i("split", 0), p.set("split_apps"))
    }
}
