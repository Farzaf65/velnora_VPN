package com.velnora.app

import androidx.compose.ui.graphics.Color

class Accent(val name: String, val a: Long, val b: Long)
class Ground(val name: String, val bg: Long, val surf: Long, val surf2: Long)

/** Colors the user can pick in "Appearance". The first entries are the Velnora defaults. */
object Skin {
    val ACCENTS = listOf(
        Accent("بنفش ولنورا", 0xFF8B5CF6, 0xFF4F46E5),
        Accent("اقیانوس", 0xFF22D3EE, 0xFF3B82F6),
        Accent("زمرد", 0xFF34D399, 0xFF22D3EE),
        Accent("جنگل", 0xFF4ADE80, 0xFFA3E635),
        Accent("خورشید", 0xFFFACC15, 0xFFFB923C),
        Accent("مرجان", 0xFFFB923C, 0xFFF43F5E),
        Accent("یاقوت", 0xFFF43F5E, 0xFFFB7185),
        Accent("صورتی", 0xFFF472B6, 0xFFC084FC),
        Accent("ارغوان", 0xFFC084FC, 0xFF818CF8),
        Accent("نیلی", 0xFF818CF8, 0xFF38BDF8),
        Accent("نئون", 0xFF00F5A0, 0xFF00D9F5),
        Accent("نقره", 0xFFCBD5E1, 0xFF94A3B8),
        Accent("نارنجی", 0xFFFF7A1A, 0xFFFF9F4A)
    )

    val GROUNDS = listOf(
        Ground("شب بنفش", 0xFF07050F, 0xFF110D20, 0xFF1A1432),
        Ground("مشکی", 0xFF000000, 0xFF0D0D10, 0xFF17171C),
        Ground("گرافیت", 0xFF0E1013, 0xFF161A1F, 0xFF20252C),
        Ground("اقیانوس شب", 0xFF06101C, 0xFF0C1A2B, 0xFF132438),
        Ground("شب جنگلی", 0xFF06120D, 0xFF0C1D15, 0xFF14291F),
        Ground("شراب", 0xFF140609, 0xFF1F0C11, 0xFF2C1219)
    )

    fun apply(p: Prefs) {
        val a = ACCENTS[p.i("accent", 0).coerceIn(0, ACCENTS.size - 1)]
        val g = GROUNDS[p.i("ground", 0).coerceIn(0, GROUNDS.size - 1)]
        C.a = Color(a.a)
        C.b = Color(a.b)
        C.bg = Color(g.bg)
        C.surf = Color(g.surf)
        C.surf2 = Color(g.surf2)
    }
}
