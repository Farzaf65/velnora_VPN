package com.velnora.app

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
private fun Section(title: String) {
    Text(title, color = C.a, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, start = 4.dp))
}

/** A row of options where exactly one is chosen. */
@Composable
private fun Seg(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.surf2).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for ((i, o) in options.withIndex()) {
            val on = i == sel
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(13.dp))
                    .then(if (on) Modifier.background(Brush.horizontalGradient(listOf(C.a, C.b))) else Modifier)
                    .clickable { onSel(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(o, color = if (on) C.fg else C.muted, fontSize = 12.5.sp, fontWeight = FontWeight.Medium) }
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().card().clickable { onChange(!on) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = C.fg, fontSize = 14.5.sp)
            Gap(4)
            Text(sub, color = C.muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        GapW(10)
        Toggle(on)
    }
}

@Composable
private fun LinkRow(icon: String, title: String, sub: String, onClick: () -> Unit) {
    Press(Modifier.fillMaxWidth(), 22.dp, onClick) {
        Row(Modifier.fillMaxWidth().card().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Ico(icon, C.a, 22.dp)
            GapW(12)
            Column(Modifier.weight(1f)) {
                Text(title, color = C.fg, fontSize = 14.5.sp)
                if (sub.isNotBlank()) {
                    Gap(3)
                    Text(sub, color = C.muted, fontSize = 12.sp)
                }
            }
            Ico("chev", C.muted, 18.dp)
        }
    }
}

@Composable
fun SettingsScreen(
    prefs: Prefs, auto: Boolean, onAuto: (Boolean) -> Unit, onBack: () -> Unit, onSubs: () -> Unit, onApps: () -> Unit
) {
    val ctx = LocalContext.current
    var proto by remember { mutableStateOf(prefs.s("proto", "auto")) }
    var reconnect by remember { mutableStateOf(prefs.b("reconnect", true)) }
    var notif by remember { mutableStateOf(prefs.b("notif", true)) }
    var dns1 by remember { mutableStateOf(prefs.s("dns1")) }
    var dns2 by remember { mutableStateOf(prefs.s("dns2")) }
    var split by remember { mutableStateOf(prefs.i("split", 0)) }
    val bad1 = dns1.isNotBlank() && !Opts.validIp(dns1)
    val bad2 = dns2.isNotBlank() && !Opts.validIp(dns2)

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
            .padding(bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PageHead("تنظیمات", onBack)

        Section("پروتکل")
        Column(Modifier.fillMaxWidth().card().padding(14.dp)) {
            Seg(listOf("طبق کانفیگ", "UDP", "TCP"), listOf("auto", "udp", "tcp").indexOf(proto).coerceAtLeast(0)) {
                proto = listOf("auto", "udp", "tcp")[it]
                prefs.put("proto", proto)
            }
            Gap(10)
            Text(
                "با UDP یا TCP، پروتکل کانفیگ عوض می‌شه. فقط وقتی کار می‌کنه که سرور همون پروتکل رو واقعاً باز گذاشته باشه.",
                color = C.muted, fontSize = 12.sp, lineHeight = 18.sp
            )
        }

        Section("اتصال")
        SwitchRow("اتصال دوباره‌ی خودکار", "با عوض‌شدن شبکه (وای‌فای ↔ دیتا) یا قطع ناگهانی، دوباره وصل می‌شه", reconnect) {
            reconnect = it; prefs.putB("reconnect", it)
        }
        SwitchRow("نوتیفیکیشن اتصال", "مدت اتصال و سرعت لحظه‌ای (فقط وقتی موتور گزارش بده)", notif) {
            notif = it; prefs.putB("notif", it)
        }

        Section("DNS دلخواه")
        Column(Modifier.fillMaxWidth().card().padding(14.dp)) {
            Field(dns1, { dns1 = it.trim(); prefs.put("dns1", dns1) }, "DNS اول (مثلاً 1.1.1.1)")
            Gap(8)
            Field(dns2, { dns2 = it.trim(); prefs.put("dns2", dns2) }, "DNS دوم (اختیاری)")
            Gap(8)
            Text(
                if (bad1 || bad2) "آدرس DNS درست نیست؛ نادیده گرفته می‌شه." else "خالی بذاری، DNS خود سرور استفاده می‌شه.",
                color = if (bad1 || bad2) C.bad else C.muted, fontSize = 12.sp
            )
        }

        Section("تونل جداگانه (Split tunneling)")
        Column(Modifier.fillMaxWidth().card().padding(14.dp)) {
            Seg(listOf("همه‌ی برنامه‌ها", "فقط انتخابی‌ها", "همه به‌جز انتخابی‌ها"), split) {
                split = it; prefs.putI("split", it)
            }
            if (split != 0) {
                Gap(10)
                Btn("انتخاب برنامه‌ها (" + fa(prefs.set("split_apps").size.toLong()) + ")", primary = false, onClick = onApps)
            }
        }

        Section("کیل‌سوییچ")
        Column(Modifier.fillMaxWidth().card().padding(14.dp)) {
            Text(
                "اندروید اجازه نمی‌ده برنامه خودش کیل‌سوییچ رو روشن کنه. از تنظیمات سیستم، ولنورا رو انتخاب کن و «Always-on VPN» و «Block connections without VPN» رو روشن کن.",
                color = C.muted, fontSize = 12.sp, lineHeight = 19.sp
            )
            Gap(10)
            Btn("باز کردن تنظیمات VPN اندروید", primary = false) {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_VPN_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
            }
        }

        Section("اشتراک‌ها")
        LinkRow("link", "مدیریت اشتراک‌ها", "افزودن، بروزرسانی و حذف لینک", onSubs)
        SwitchRow("بروزرسانی خودکار اشتراک‌ها", "هر ۱۲ ساعت، وقتی اینترنت وصله", auto, onAuto)

        Text(
            "تنظیمات اتصال از دفعه‌ی بعدی که وصل می‌شی اعمال می‌شن.",
            color = C.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
        )
    }
}

class AppRow(val pkg: String, val label: String)

@Composable
fun AppsScreen(prefs: Prefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppRow>?>(null) }
    var chosen by remember { mutableStateOf(prefs.set("split_apps")) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .map { AppRow(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .filter { it.pkg != ctx.packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
        }
    }
    val list = (apps ?: emptyList()).filter { q.isBlank() || it.label.contains(q.trim(), true) || it.pkg.contains(q.trim(), true) }
    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { PageHead("انتخاب برنامه‌ها", onBack) }
        item {
            Text(
                fa(chosen.size.toLong()) + " برنامه انتخاب شده · " +
                    if (prefs.i("split", 0) == 1) "فقط همین‌ها از VPN رد می‌شن" else "همه به‌جز همین‌ها از VPN رد می‌شن",
                color = C.muted, fontSize = 12.sp
            )
        }
        item { Field(q, { q = it }, "جست‌وجوی برنامه") }
        if (apps == null) item { Text("در حال خوندن برنامه‌ها…", color = C.a, fontSize = 13.sp) }
        items(list, key = { it.pkg }) { a ->
            val on = a.pkg in chosen
            Row(
                Modifier.fillMaxWidth().card(16.dp).clickable {
                    chosen = if (on) chosen - a.pkg else chosen + a.pkg
                    prefs.putSet("split_apps", chosen)
                }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(a.label, color = C.fg, fontSize = 14.sp, maxLines = 1)
                    Text("‎" + a.pkg, color = C.muted, fontSize = 10.5.sp, maxLines = 1)
                }
                GapW(10)
                Box(
                    Modifier.size(22.dp).background(if (on) C.a else C.surf2, RoundedCornerShape(7.dp)),
                    contentAlignment = Alignment.Center
                ) { if (on) Ico("check", C.fg, 15.dp) }
            }
        }
        item { Gap(24) }
    }
}

@Composable
fun LogScreen(logs: List<String>, onBack: () -> Unit, onCopy: () -> Unit, onClear: () -> Unit) {
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp)) {
        PageHead("لاگ اتصال", onBack) {
            RoundBtn("copy", onCopy)
            GapW(8)
            RoundBtn("trash", onClear)
        }
        Text(
            "فقط رویدادهای واقعی برنامه و موتور اینجا ثبت می‌شن. رمزها هیچ‌وقت توی لاگ نمی‌آن.",
            color = C.muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp)
        )
        if (logs.isEmpty()) {
            Column(Modifier.fillMaxWidth().card().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Ico("log", C.muted, 30.dp)
                Gap(10)
                Text("هنوز رویدادی ثبت نشده.", color = C.muted, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().card(16.dp).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                items(logs.asReversed().take(400)) { l ->
                    Text(
                        "‎" + l,
                        color = if (l.contains("خطا")) C.bad else C.fg, fontSize = 11.5.sp,
                        fontFamily = FontFamily.Monospace, lineHeight = 17.sp
                    )
                }
            }
        }
    }
}

@Composable
fun AppearanceScreen(prefs: Prefs, onBack: () -> Unit, onIcon: (Int) -> Unit) {
    val ctx = LocalContext.current
    var acc by remember { mutableStateOf(prefs.i("accent", 0)) }
    var gr by remember { mutableStateOf(prefs.i("ground", 0)) }
    var ic by remember { mutableStateOf(AppIcon.current(ctx)) }
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
            .padding(bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PageHead("ظاهر و آیکون", onBack)

        Section("رنگ اصلی")
        Column(Modifier.fillMaxWidth().card().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (row in Skin.ACCENTS.withIndex().toList().chunked(4)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for ((i, a) in row) {
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable {
                                acc = i; prefs.putI("accent", i); Skin.apply(prefs)
                            }.padding(vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.size(44.dp).clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(Color(a.a), Color(a.b))))
                                    .border(if (i == acc) 3.dp else 0.dp, C.fg, CircleShape),
                                contentAlignment = Alignment.Center
                            ) { if (i == acc) Ico("check", C.fg, 20.dp) }
                            Gap(4)
                            Text(a.name, color = C.muted, fontSize = 10.5.sp, maxLines = 1)
                        }
                    }
                    repeat(4 - row.size) { Box(Modifier.weight(1f)) }
                }
            }
        }

        Section("پس‌زمینه")
        Column(Modifier.fillMaxWidth().card().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (row in Skin.GROUNDS.withIndex().toList().chunked(3)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for ((i, g) in row) {
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable {
                                gr = i; prefs.putI("ground", i); Skin.apply(prefs)
                            }.padding(vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(12.dp)).background(Color(g.bg))
                                    .border(if (i == gr) 2.dp else 1.dp, if (i == gr) C.a else C.line, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) { Box(Modifier.size(22.dp).clip(RoundedCornerShape(7.dp)).background(Color(g.surf2))) }
                            Gap(4)
                            Text(g.name, color = C.muted, fontSize = 10.5.sp, maxLines = 1)
                        }
                    }
                    repeat(3 - row.size) { Box(Modifier.weight(1f)) }
                }
            }
        }

        Section("آیکون برنامه")
        Column(Modifier.fillMaxWidth().card().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            for (row in AppIcon.NAMES.indices.toList().chunked(3)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (i in row) {
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).clickable {
                                if (i != ic) {
                                    ic = i
                                    onIcon(i)
                                }
                            }.padding(vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Image(
                                painterResource(AppIcon.PREVIEWS[i]), null,
                                Modifier.size(64.dp).clip(RoundedCornerShape(18.dp))
                                    .border(if (i == ic) 3.dp else 0.dp, C.a, RoundedCornerShape(18.dp))
                            )
                            Gap(4)
                            Text(AppIcon.NAMES[i], color = if (i == ic) C.fg else C.muted, fontSize = 11.sp, maxLines = 1)
                        }
                    }
                    repeat(3 - row.size) { Box(Modifier.weight(1f)) }
                }
            }
            Text(
                "با تغییر آیکون، برنامه خودش بسته می‌شه تا لانچر آیکون جدید رو نشون بده؛ دوباره بازش کن.",
                color = C.muted, fontSize = 12.sp, lineHeight = 18.sp
            )
        }
    }
}

@Composable
private fun KV(k: String, v: String, col: Color = C.fg) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(k, color = C.muted, fontSize = 12.5.sp, modifier = Modifier.weight(1f))
        Text(v, color = col, fontSize = 13.sp, maxLines = 1)
    }
}

/** Full page for one server: everything the file says about it, plus editing. */
@Composable
fun DetailScreen(
    c: Conf, sub: Subscr?, saved: Boolean, ping: Long?, picked: Boolean,
    onBack: () -> Unit, onConnect: () -> Unit, onPing: () -> Unit, onForget: () -> Unit,
    onDelete: () -> Unit, onSave: (String, String, String) -> Unit
) {
    var show by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(Privacy.name(c.name)) }
    var u by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var hideNote by remember { mutableStateOf(false) }
    val pt = pingText(ping)
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
            .padding(bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PageHead("جزئیات سرور", onBack)
        Column(Modifier.fillMaxWidth().card().padding(16.dp)) {
            Text(Privacy.name(c.name), color = C.fg, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 2)
            Gap(12)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip(c.proto.uppercase(), C.a)
                if (picked) Chip("انتخاب‌شده", C.ok)
            }
            Gap(14)
            Btn("اتصال با این سرور", onClick = onConnect)
        }

        Section("اطلاعات اتصال")
        Column(Modifier.fillMaxWidth().card().padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("آدرس", color = C.muted, fontSize = 12.5.sp, modifier = Modifier.weight(1f))
                Text("••••••••", color = C.fg, fontSize = 13.sp, maxLines = 1)
                GapW(10)
                Box(Modifier.clickable { hideNote = true }.padding(4.dp)) { Ico("eye", C.muted, 20.dp) }
            }
            if (hideNote) {
                Text(Privacy.NOTE, color = C.warn, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            KV("پورت", "••••")
            KV("پروتکل", c.proto.uppercase())
            KV("رمزنگاری (cipher)", if (c.cipher.isBlank()) "در فایل مشخص نشده" else "‎" + c.cipher, if (c.cipher.isBlank()) C.muted else C.fg)
            KV("هش احراز (auth)", if (c.authAlg.isBlank()) "در فایل مشخص نشده" else "‎" + c.authAlg, if (c.authAlg.isBlank()) C.muted else C.fg)
            KV("لایه‌ی TLS", if (c.tls.isBlank()) "ندارد / نامشخص" else "‎" + c.tls, if (c.tls.isBlank()) C.muted else C.fg)
            KV("پینگ", pt.first, pt.second)
            Gap(4)
            Btn("سنجش پینگ", primary = false, onClick = onPing)
            Gap(8)
        }

        Section("ویرایش")
        Column(Modifier.fillMaxWidth().card().padding(16.dp)) {
            Field(name, { name = it }, "نام سرور")
            if (c.needsAuth) {
                Gap(14)
                Text(
                    if (saved) "نام کاربری و رمز ذخیره شده؛ برای تغییر، مقدار جدید بنویس" else "نام کاربری و رمز (اختیاری)",
                    color = C.muted, fontSize = 12.sp
                )
                Gap(8)
                Field(u, { u = it }, "نام کاربری")
                Gap(8)
                Field(p, { p = it }, "رمز عبور", pass = true)
            }
            Gap(14)
            Btn("ذخیره") { onSave(name, u.trim(), p) }
            if (saved) {
                Gap(8)
                Btn("پاک کردن رمزهای ذخیره‌شده", primary = false, onClick = onForget)
            }
            Gap(8)
            Btn("حذف سرور", primary = false, danger = true, onClick = onDelete)
        }
    }
}
