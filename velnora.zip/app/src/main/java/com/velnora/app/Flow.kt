package com.velnora.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** First screen: only the Velnora logo, then it fades out. */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        a.animateTo(1f, tween(450))
        delay(750)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(C.bg), contentAlignment = Alignment.Center) {
        Image(
            painterResource(R.drawable.velnora_logo), null,
            Modifier.size(124.dp).scale(0.86f + 0.14f * a.value).alpha(a.value).clip(RoundedCornerShape(30.dp))
        )
    }
}

/** Top bar with the menu button on one side and optional actions on the other. */
@Composable
fun TopBar(title: String, onMenu: (() -> Unit)?, onBack: (() -> Unit)?, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) RoundBtn("back", onBack) else if (onMenu != null) RoundBtn("menu", onMenu)
        GapW(12)
        Text(title, color = C.fg, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
private fun Tabs(labels: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth()) {
            for ((i, l) in labels.withIndex()) {
                val on = i == sel
                Column(Modifier.weight(1f).clickable { onSel(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        l, color = if (on) C.a else C.fg, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(vertical = 14.dp)
                    )
                    Box(Modifier.fillMaxWidth().height(3.dp).background(if (on) C.a else C.line))
                }
            }
        }
    }
}

@Composable
private fun HelpBar(text: String, onClick: () -> Unit) {
    Press(Modifier.fillMaxWidth(), 16.dp, onClick) {
        Row(Modifier.fillMaxWidth().background(C.surf2).padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Ico("info", C.muted, 20.dp)
            GapW(12)
            Text(text, color = C.fg, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Ico("chev", C.muted, 18.dp)
        }
    }
}

/** "Get connected": add a server by link or by file. */
@Composable
fun GetConnectedScreen(
    busy: Boolean, canLeave: Boolean, onMenu: () -> Unit, onBack: () -> Unit,
    onNext: (String) -> Unit, onBrowse: () -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    var url by remember { mutableStateOf("") }
    var help by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp).padding(bottom = 14.dp)) {
        TopBar("اتصال بگیر", if (canLeave) null else onMenu, if (canLeave) onBack else null)
        Tabs(listOf("لینک", "فایل"), tab) { tab = it }
        if (tab == 0) {
            Gap(20)
            Field(url, { url = it }, "آدرس لینک اشتراک یا متن کانفیگ", lines = 3)
            Gap(10)
            Text(
                "لینک اشتراک، آدرس مستقیم فایل .ovpn یا خود متن کانفیگ رو بچسبون.",
                color = C.muted, fontSize = 12.5.sp, lineHeight = 19.sp
            )
            Box(Modifier.weight(1f))
            HelpBar("لینک من چیه؟") { help = true }
            Gap(12)
            Btn(if (busy) "در حال دریافت…" else "ادامه") { if (!busy && url.isNotBlank()) onNext(url.trim()) }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                Gap(44)
                Box(
                    Modifier.size(width = 74.dp, height = 96.dp).border(2.dp, C.fg, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) { Text(".OVPN", color = C.fg, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Gap(26)
                Text(
                    "فایل پروفایل رو انتخاب کن.", color = C.fg, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Gap(8)
                Text(
                    "فایل‌های .ovpn و .conf و همین‌طور ZIP (همراه گواهی‌ها) پشتیبانی می‌شه. اگه ZIP چند کانفیگ داشته باشه، همه‌شون جدا اضافه می‌شن.",
                    color = C.muted, fontSize = 14.sp, lineHeight = 23.sp, textAlign = TextAlign.Center
                )
            }
            HelpBar("فایل .ovpn ندارم؟") { help = true }
            Gap(12)
            Btn("انتخاب فایل", onClick = onBrowse)
        }
    }
    if (help) {
        Sheet(onDismiss = { help = false }, title = if (tab == 0) "لینک من چیه؟" else "فایل .ovpn از کجا بیارم؟") {
            Text(
                if (tab == 0) {
                    "لینک اشتراک رو سرویس‌دهنده‌ت بهت می‌ده؛ معمولاً یه آدرس https است. اگه لینک نام کاربری و رمز می‌خواد، همون رو داخل لینک بنویس (https://user:pass@…). با اضافه‌شدن لینک، همه‌ی سرورهاش خودکار وارد می‌شن و حجم و تاریخ انقضا (اگه سرویس‌دهنده بده) نشون داده می‌شه."
                } else {
                    "فایل رو سرویس‌دهنده یا ادمین سرور می‌ده. پسوندش معمولاً .ovpn یا .conf است. اگه گواهی‌ها جدا هستن، همه رو توی یک ZIP بذار و ZIP رو انتخاب کن."
                },
                color = C.muted, fontSize = 13.sp, lineHeight = 21.sp
            )
            Gap(14)
            Btn("باشه", primary = false) { help = false }
        }
    }
}

/** Asks before importing, with the file's name. */
@Composable
fun ConfirmImport(items: List<Pair<String, String>>, onOk: () -> Unit, onCancel: () -> Unit) {
    val one = items.size == 1
    Sheet(onDismiss = onCancel, title = "پروفایل وارد بشه؟") {
        Text(
            if (one) "می‌خوای پروفایل «" + items[0].first + "» وارد برنامه بشه؟"
            else "از این فایل " + fa(items.size.toLong()) + " پروفایل پیدا شد. همه وارد بشن؟",
            color = C.muted, fontSize = 14.sp, lineHeight = 22.sp
        )
        Gap(18)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("لغو", primary = false, modifier = Modifier.weight(1f), onClick = onCancel)
            Btn("تأیید", modifier = Modifier.weight(1f), onClick = onOk)
        }
    }
}

/** Shows the profile that was just imported: its name can be changed, the server is locked. */
@Composable
fun ImportedScreen(c: Conf, onBack: () -> Unit, onProfiles: (String) -> Unit, onConnect: (String) -> Unit) {
    var name by remember(c.id) { mutableStateOf(c.name) }
    val e = expInfo(c.expiresAt)
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp).padding(bottom = 14.dp)) {
        TopBar("پروفایل واردشده", null, onBack)
        Gap(14)
        Text("نام پروفایل", color = C.muted, fontSize = 12.5.sp)
        Gap(6)
        Field(name, { name = it }, "نام پروفایل")
        Gap(18)
        Text("آدرس سرور (قفل‌شده)", color = C.muted, fontSize = 12.5.sp)
        Gap(6)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.surf).padding(14.dp)) {
            Text("‎" + c.host, color = C.fg, fontSize = 14.sp)
        }
        Gap(18)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip(c.proto.uppercase() + " · " + fa(c.port), C.a)
            Chip(e.first, e.second)
            if (c.needsAuth || c.keyEnc) Chip("رمز لازمه", C.warn)
        }
        Box(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Btn("پروفایل‌ها", primary = false, modifier = Modifier.weight(1f)) { onProfiles(name.trim().ifBlank { c.name }) }
            Btn("اتصال", modifier = Modifier.weight(1f)) { onConnect(name.trim().ifBlank { c.name }) }
        }
    }
}

/** Main screen: the status of the tunnel on top, then every profile with its on/off switch. */
@Composable
fun ProfilesScreen(
    confs: List<Conf>, sel: String?, st: VState, note: String, since: Long, down: Long, up: Long,
    sub: Subscr?, last: String?, pings: Map<String, Long>, measuring: Boolean,
    onToggle: (Conf) -> Unit, onEdit: (Conf) -> Unit, onAdd: () -> Unit, onMenu: () -> Unit,
    onLog: () -> Unit, onFastest: () -> Unit, onPing: () -> Unit
) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(st) {
        while (st == VState.On) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val label = when (st) {
        VState.Off -> "قطع"
        VState.Connecting -> "در حال اتصال…"
        VState.On -> "وصل"
        VState.Failed -> "ناموفق"
    }
    val labelCol = when (st) {
        VState.Off -> C.fg
        VState.Connecting -> C.a
        VState.On -> C.ok
        VState.Failed -> C.bad
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            item {
                TopBar("پروفایل‌ها", onMenu, null) {
                    RoundBtn("fast", onFastest)
                    GapW(8)
                    RoundBtn("log", onLog)
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Dot(labelCol)
                    GapW(8)
                    Text(label, color = labelCol, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(
                        if (measuring) "در حال سنجش پینگ…" else "سنجش پینگ", color = C.a, fontSize = 12.5.sp,
                        modifier = Modifier.clickable { if (!measuring) onPing() }.padding(6.dp)
                    )
                }
            }
            if (note.isNotBlank() && st == VState.Failed) {
                item { Text(note, color = C.bad, fontSize = 12.5.sp, modifier = Modifier.padding(bottom = 8.dp)) }
            }
            if (st == VState.On || st == VState.Connecting) {
                item {
                    Column(Modifier.fillMaxWidth().card().padding(14.dp)) {
                        Row(Modifier.fillMaxWidth()) {
                            StatCell("مدت اتصال", if (st == VState.On && since > 0) dur(now - since) else "—", Modifier.weight(1f))
                            StatCell("دانلود", fmtSpeed(down), Modifier.weight(1f))
                            StatCell("آپلود", fmtSpeed(up), Modifier.weight(1f))
                        }
                        if (sub != null) {
                            Gap(12)
                            val left = if (sub.total > 0 && sub.used >= 0) sub.total - sub.used else -1L
                            val e = expInfo(if (sub.expire > 0) sub.expire else null)
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    if (left >= 0) fmtBytes(left) + " باقی‌مانده از " + fmtBytes(sub.total) else "حجم باقی‌مانده: نامشخص",
                                    color = C.fg, fontSize = 12.5.sp, modifier = Modifier.weight(1f)
                                )
                                Chip(e.first, e.second)
                            }
                        }
                    }
                }
            }
            if (last != null && st != VState.On) {
                item { Text("آخرین اتصال: $last", color = C.muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp)) }
            }
            if (confs.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().card().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("هنوز پروفایلی نداری.", color = C.muted, fontSize = 13.sp)
                        Gap(6)
                        Text("با دکمه‌ی + فایل یا لینک اشتراک اضافه کن.", color = C.muted, fontSize = 12.sp)
                    }
                }
            }
            items(confs, key = { it.id }) { c ->
                val on = c.id == sel && (st == VState.On || st == VState.Connecting)
                val e = expInfo(c.expiresAt)
                val p = pings[c.id]
                Column(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.clickable { onToggle(c) }.padding(2.dp)) { Toggle(on) }
                        GapW(14)
                        Column(Modifier.weight(1f).clickable { onEdit(c) }) {
                            Text(c.name, color = C.fg, fontSize = 16.sp, maxLines = 1, fontWeight = FontWeight.Medium)
                            Gap(3)
                            Text(
                                "‎" + c.host + " · " + c.proto.uppercase() + " " + c.port,
                                color = C.muted, fontSize = 12.sp, maxLines = 1
                            )
                            Gap(6)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Chip(e.first, e.second)
                                if (p != null) {
                                    val pt = pingText(p)
                                    Chip(pt.first, pt.second)
                                }
                                if (c.needsAuth || c.keyEnc) Chip("رمز", C.warn)
                            }
                        }
                        GapW(8)
                        Box(Modifier.clip(CircleShape).clickable { onEdit(c) }.padding(10.dp)) { Ico("pen", C.fg, 22.dp) }
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
                }
            }
            item { Gap(96) }
        }
        Box(
            Modifier.align(Alignment.BottomStart).systemBarsPadding().padding(20.dp).size(58.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(C.a, C.b))).clickable { onAdd() },
            contentAlignment = Alignment.Center
        ) { Ico("plus", C.fg, 28.dp) }
    }
}

@Composable
private fun StatCell(k: String, v: String, modifier: Modifier) {
    Column(modifier) {
        Text(k, color = C.muted, fontSize = 11.sp)
        Gap(4)
        Text(v, color = C.fg, fontSize = 14.sp, maxLines = 1)
    }
}

private fun dur(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    return fa("%02d:%02d:%02d".format(t / 3600, (t % 3600) / 60, t % 60))
}
