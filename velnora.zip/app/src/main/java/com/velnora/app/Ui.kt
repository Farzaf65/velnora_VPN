package com.velnora.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

object C {
    // Accent and background can be changed by the user (see Skin), so these are observable.
    var bg by mutableStateOf(Color(0xFF07050F))
    var surf by mutableStateOf(Color(0xFF110D20))
    var surf2 by mutableStateOf(Color(0xFF1A1432))
    val line = Color(0x1FFFFFFF)
    val fg = Color(0xFFEDE9FE)
    val muted = Color(0xFF9A93B8)
    var a by mutableStateOf(Color(0xFF8B5CF6))
    var b by mutableStateOf(Color(0xFF4F46E5))
    val ok = Color(0xFF34D399)
    val warn = Color(0xFFFBBF24)
    val bad = Color(0xFFF87171)
}

fun fa(s: String): String = s.map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")
fun fa(n: Long): String = fa(n.toString())

/** Date in the Persian calendar, shown with Persian digits. */
fun faDate(ms: Long): String = try {
    val c = android.icu.util.PersianCalendar(java.util.Date(ms))
    fa(
        "%04d/%02d/%02d".format(
            c.get(android.icu.util.Calendar.YEAR), c.get(android.icu.util.Calendar.MONTH) + 1,
            c.get(android.icu.util.Calendar.DAY_OF_MONTH)
        )
    )
} catch (e: Throwable) {
    "—"
}

fun fmtBytes(b: Long): String {
    if (b < 0) return "؟"
    val gb = b / 1073741824.0
    return if (gb >= 1) fa("%.1f".format(gb)) + " گیگ" else fa("%.0f".format(b / 1048576.0)) + " مگ"
}

/** Text and color for the remaining time of a config. */
fun expInfo(ms: Long?): Pair<String, Color> {
    if (ms == null) return "انقضا نامشخص" to C.muted
    val now = System.currentTimeMillis()
    if (ms < now) return "منقضی شده" to C.bad
    val d = (ms - now) / 86400000L
    return when {
        d <= 0 -> "کمتر از یک روز" to C.warn
        d <= 7 -> fa(d) + " روز مانده" to C.warn
        else -> fa(d) + " روز مانده" to C.ok
    }
}

@Composable
fun Ico(kind: String, color: Color, sz: Dp = 22.dp) {
    Canvas(Modifier.size(sz)) {
        val w = size.width
        val sw = w * 0.085f
        val st = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            "plus" -> {
                drawLine(color, Offset(w * .2f, w * .5f), Offset(w * .8f, w * .5f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .5f, w * .2f), Offset(w * .5f, w * .8f), sw, StrokeCap.Round)
            }
            "close" -> {
                drawLine(color, Offset(w * .25f, w * .25f), Offset(w * .75f, w * .75f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .75f, w * .25f), Offset(w * .25f, w * .75f), sw, StrokeCap.Round)
            }
            "link" -> rotate(-45f) {
                drawRoundRect(color, Offset(w * .04f, w * .36f), Size(w * .5f, w * .28f), CornerRadius(w * .14f), style = st)
                drawRoundRect(color, Offset(w * .46f, w * .36f), Size(w * .5f, w * .28f), CornerRadius(w * .14f), style = st)
            }
            "file" -> {
                drawRoundRect(color, Offset(w * .2f, w * .1f), Size(w * .6f, w * .8f), CornerRadius(w * .1f), style = st)
                drawLine(color, Offset(w * .34f, w * .4f), Offset(w * .66f, w * .4f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .34f, w * .6f), Offset(w * .66f, w * .6f), sw, StrokeCap.Round)
            }
            "lock" -> {
                drawRoundRect(color, Offset(w * .22f, w * .44f), Size(w * .56f, w * .42f), CornerRadius(w * .1f), style = st)
                drawArc(color, 180f, 180f, false, Offset(w * .32f, w * .16f), Size(w * .36f, w * .4f), style = st)
            }
            "eye" -> {
                drawOval(color, Offset(w * .08f, w * .28f), Size(w * .84f, w * .44f), style = st)
                drawCircle(color, w * .1f, Offset(w * .5f, w * .5f))
            }
            "eyeoff" -> {
                drawOval(color, Offset(w * .08f, w * .28f), Size(w * .84f, w * .44f), style = st)
                drawLine(color, Offset(w * .2f, w * .82f), Offset(w * .8f, w * .18f), sw, StrokeCap.Round)
            }
            "trash" -> {
                drawLine(color, Offset(w * .18f, w * .27f), Offset(w * .82f, w * .27f), sw, StrokeCap.Round)
                drawRoundRect(color, Offset(w * .26f, w * .27f), Size(w * .48f, w * .6f), CornerRadius(w * .08f), style = st)
                drawLine(color, Offset(w * .4f, w * .14f), Offset(w * .6f, w * .14f), sw, StrokeCap.Round)
            }
            "refresh" -> {
                drawArc(color, -50f, 280f, false, Offset(w * .15f, w * .15f), Size(w * .7f, w * .7f), style = st)
                drawLine(color, Offset(w * .72f, w * .1f), Offset(w * .72f, w * .3f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .72f, w * .3f), Offset(w * .52f, w * .3f), sw, StrokeCap.Round)
            }
            "clock" -> {
                drawCircle(color, w * .38f, Offset(w * .5f, w * .5f), style = st)
                drawLine(color, Offset(w * .5f, w * .3f), Offset(w * .5f, w * .5f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .5f, w * .5f), Offset(w * .64f, w * .58f), sw, StrokeCap.Round)
            }
            "check" -> {
                drawLine(color, Offset(w * .22f, w * .52f), Offset(w * .42f, w * .72f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .42f, w * .72f), Offset(w * .8f, w * .3f), sw, StrokeCap.Round)
            }
            "back" -> {
                drawLine(color, Offset(w * .38f, w * .22f), Offset(w * .66f, w * .5f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .66f, w * .5f), Offset(w * .38f, w * .78f), sw, StrokeCap.Round)
            }
            "chev" -> {
                drawLine(color, Offset(w * .62f, w * .22f), Offset(w * .34f, w * .5f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .34f, w * .5f), Offset(w * .62f, w * .78f), sw, StrokeCap.Round)
            }
            "dots" -> {
                drawCircle(color, w * .07f, Offset(w * .5f, w * .2f))
                drawCircle(color, w * .07f, Offset(w * .5f, w * .5f))
                drawCircle(color, w * .07f, Offset(w * .5f, w * .8f))
            }
            "menu" -> {
                drawLine(color, Offset(w * .2f, w * .3f), Offset(w * .8f, w * .3f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .5f), Offset(w * .8f, w * .5f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .7f), Offset(w * .62f, w * .7f), sw, StrokeCap.Round)
            }
            "chat" -> {
                drawRoundRect(color, Offset(w * .14f, w * .18f), Size(w * .72f, w * .5f), CornerRadius(w * .14f), style = st)
                drawLine(color, Offset(w * .36f, w * .68f), Offset(w * .3f, w * .86f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .3f, w * .86f), Offset(w * .5f, w * .68f), sw, StrokeCap.Round)
            }
            "mail" -> {
                drawRoundRect(color, Offset(w * .12f, w * .24f), Size(w * .76f, w * .52f), CornerRadius(w * .1f), style = st)
                drawLine(color, Offset(w * .14f, w * .3f), Offset(w * .5f, w * .56f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .5f, w * .56f), Offset(w * .86f, w * .3f), sw, StrokeCap.Round)
            }
            "wave" -> {
                drawLine(color, Offset(w * .16f, w * .5f), Offset(w * .84f, w * .22f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .84f, w * .22f), Offset(w * .6f, w * .84f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .6f, w * .84f), Offset(w * .46f, w * .56f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .46f, w * .56f), Offset(w * .16f, w * .5f), sw, StrokeCap.Round)
            }
            "gear" -> {
                drawCircle(color, w * .16f, Offset(w * .5f, w * .5f), style = st)
                drawCircle(color, w * .34f, Offset(w * .5f, w * .5f), style = Stroke(sw, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(w * .13f, w * .1f))))
            }
            "palette" -> {
                drawCircle(color, w * .36f, Offset(w * .5f, w * .5f), style = st)
                drawCircle(color, w * .05f, Offset(w * .38f, w * .4f))
                drawCircle(color, w * .05f, Offset(w * .56f, w * .34f))
                drawCircle(color, w * .05f, Offset(w * .66f, w * .5f))
            }
            "log" -> {
                drawLine(color, Offset(w * .2f, w * .26f), Offset(w * .8f, w * .26f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .5f), Offset(w * .66f, w * .5f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .74f), Offset(w * .5f, w * .74f), sw, StrokeCap.Round)
            }
            "shield" -> {
                drawLine(color, Offset(w * .5f, w * .1f), Offset(w * .8f, w * .22f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .8f, w * .22f), Offset(w * .78f, w * .55f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .78f, w * .55f), Offset(w * .5f, w * .9f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .5f, w * .9f), Offset(w * .22f, w * .55f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .22f, w * .55f), Offset(w * .2f, w * .22f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .22f), Offset(w * .5f, w * .1f), sw, StrokeCap.Round)
            }
            "apps" -> {
                for (x in listOf(.22f, .58f)) for (y in listOf(.22f, .58f)) {
                    drawRoundRect(color, Offset(w * x, w * y), Size(w * .2f, w * .2f), CornerRadius(w * .05f), style = st)
                }
            }
            "globe" -> {
                drawCircle(color, w * .38f, Offset(w * .5f, w * .5f), style = st)
                drawOval(color, Offset(w * .34f, w * .12f), Size(w * .32f, w * .76f), style = st)
                drawLine(color, Offset(w * .12f, w * .5f), Offset(w * .88f, w * .5f), sw, StrokeCap.Round)
            }
            "bell" -> {
                drawArc(color, 180f, 180f, false, Offset(w * .26f, w * .16f), Size(w * .48f, w * .5f), style = st)
                drawLine(color, Offset(w * .26f, w * .42f), Offset(w * .2f, w * .72f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .74f, w * .42f), Offset(w * .8f, w * .72f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .72f), Offset(w * .8f, w * .72f), sw, StrokeCap.Round)
                drawCircle(color, w * .05f, Offset(w * .5f, w * .84f))
            }
            "info" -> {
                drawCircle(color, w * .38f, Offset(w * .5f, w * .5f), style = st)
                drawLine(color, Offset(w * .5f, w * .46f), Offset(w * .5f, w * .68f), sw, StrokeCap.Round)
                drawCircle(color, w * .045f, Offset(w * .5f, w * .32f))
            }
            "copy" -> {
                drawRoundRect(color, Offset(w * .3f, w * .3f), Size(w * .52f, w * .56f), CornerRadius(w * .08f), style = st)
                drawLine(color, Offset(w * .2f, w * .6f), Offset(w * .2f, w * .16f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .16f), Offset(w * .6f, w * .16f), sw, StrokeCap.Round)
            }
            "fast" -> {
                drawArc(color, 160f, 220f, false, Offset(w * .14f, w * .2f), Size(w * .72f, w * .72f), style = st)
                drawLine(color, Offset(w * .5f, w * .56f), Offset(w * .66f, w * .34f), sw, StrokeCap.Round)
            }
            "dns" -> {
                drawRoundRect(color, Offset(w * .16f, w * .2f), Size(w * .68f, w * .24f), CornerRadius(w * .06f), style = st)
                drawRoundRect(color, Offset(w * .16f, w * .56f), Size(w * .68f, w * .24f), CornerRadius(w * .06f), style = st)
            }
            "pen" -> {
                drawLine(color, Offset(w * .26f, w * .74f), Offset(w * .74f, w * .26f), sw * 1.9f, StrokeCap.Round)
                drawLine(color, Offset(w * .2f, w * .8f), Offset(w * .3f, w * .8f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .6f, w * .2f), Offset(w * .8f, w * .4f), sw, StrokeCap.Round)
            }
            "bolt" -> {
                drawLine(color, Offset(w * .56f, w * .1f), Offset(w * .28f, w * .54f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .28f, w * .54f), Offset(w * .72f, w * .54f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * .72f, w * .54f), Offset(w * .44f, w * .9f), sw, StrokeCap.Round)
            }
        }
    }
}

fun Modifier.card(r: Dp = 22.dp): Modifier {
    val s = RoundedCornerShape(r)
    return this.clip(s).background(C.surf).border(1.dp, C.line, s)
}

/** A tappable surface that shrinks a little while it is pressed. */
@Composable
fun Press(modifier: Modifier = Modifier, shape: Dp = 22.dp, onClick: () -> Unit, content: @Composable () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val k by animateFloatAsState(if (pressed) 0.97f else 1f, tween(120), label = "press")
    Box(
        modifier.graphicsLayer { scaleX = k; scaleY = k }.clip(RoundedCornerShape(shape))
            .clickable(src, null) { onClick() }
    ) { content() }
}

@Composable
fun Btn(text: String, primary: Boolean = true, danger: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val bgm = when {
        danger -> Modifier.background(C.bad.copy(alpha = 0.16f))
        primary -> Modifier.background(Brush.horizontalGradient(listOf(C.a, C.b)))
        else -> Modifier.background(C.surf2)
    }
    Press(modifier, 18.dp, onClick) {
        Box(Modifier.fillMaxWidth().then(bgm).padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
            Text(
                text, color = if (danger) C.bad else C.fg, fontSize = 14.5.sp,
                fontWeight = if (primary) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
fun Field(
    value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier,
    lines: Int = 1, pass: Boolean = false
) {
    BasicTextField(
        value = value, onValueChange = onChange,
        modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.surf2).padding(14.dp),
        textStyle = TextStyle(color = C.fg, fontSize = 14.sp),
        cursorBrush = SolidColor(C.a),
        singleLine = lines == 1,
        minLines = lines,
        maxLines = if (lines == 1) 1 else 12,
        visualTransformation = if (pass) PasswordVisualTransformation() else VisualTransformation.None,
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) Text(hint, color = C.muted, fontSize = 14.sp)
                inner()
            }
        }
    )
}

/** Floating card used for every question or form. */
@Composable
fun Sheet(onDismiss: () -> Unit, title: String, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val s = RoundedCornerShape(28.dp)
        Column(
            Modifier.padding(horizontal = 22.dp).fillMaxWidth().clip(s).background(C.surf).border(1.dp, C.line, s)
                .padding(20.dp)
        ) {
            Text(title, color = C.fg, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Start)
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
fun Chip(text: String, color: Color) {
    Box(
        Modifier.clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.14f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) { Text(text, color = color, fontSize = 11.sp) }
}

@Composable
fun RoundBtn(kind: String, onClick: () -> Unit) {
    Press(Modifier.size(42.dp), 21.dp, onClick) {
        Box(Modifier.size(42.dp).background(C.surf2), contentAlignment = Alignment.Center) { Ico(kind, C.fg, 20.dp) }
    }
}

@Composable
fun Dot(color: Color) {
    Box(Modifier.size(8.dp).clip(CircleShape).background(color))
}

@Composable
fun Gap(h: Int) = Spacer(Modifier.height(h.dp))

@Composable
fun GapW(w: Int) = Spacer(Modifier.width(w.dp))

@Composable
fun SpaceRow(content: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { content() }
}

/** On/off switch used by the settings pages. */
@Composable
fun Toggle(on: Boolean) {
    Box(
        Modifier.width(46.dp).height(26.dp).clip(CircleShape).background(if (on) C.a else C.surf2).padding(3.dp),
        contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
    ) { Box(Modifier.size(20.dp).clip(CircleShape).background(C.fg)) }
}
