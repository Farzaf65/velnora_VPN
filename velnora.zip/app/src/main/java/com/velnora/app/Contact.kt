package com.velnora.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Contact addresses. Change them here if Velnora gets its own support account or channel. */
object Reach {
    const val SUPPORT = "FARZAD_KM12345"
    const val CHANNEL = "last_circle_king"
    const val MAIL = "farzad.km15@gmail.com"

    private fun start(ctx: Context, i: Intent, title: String): Boolean = try {
        val c = Intent.createChooser(i, title)
        c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(c)
        true
    } catch (e: Exception) {
        false
    }

    fun telegram(ctx: Context, id: String): Boolean =
        start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$id")), "باز کردن با")

    fun mail(ctx: Context): Boolean {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
        i.putExtra(Intent.EXTRA_EMAIL, arrayOf(MAIL))
        i.putExtra(Intent.EXTRA_SUBJECT, "درخواست پشتیبانی ولنورا")
        return start(ctx, i, "انتخاب برنامه ایمیل")
    }
}

/** Same header used by every inner page. */
@Composable
fun PageHead(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        RoundBtn("back", onBack)
        GapW(12)
        Text(title, color = C.fg, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
private fun ContactOption(icon: String, title: String, sub: String, onClick: () -> Unit) {
    Press(Modifier.fillMaxWidth(), 22.dp, onClick) {
        Row(Modifier.fillMaxWidth().card().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Brush.linearGradient(listOf(C.a, C.b))),
                contentAlignment = Alignment.Center
            ) { Ico(icon, C.fg, 22.dp) }
            GapW(14)
            Column(Modifier.weight(1f)) {
                Text(title, color = C.fg, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Gap(3)
                Text(sub, color = C.muted, fontSize = 12.sp)
            }
            Ico("chev", C.muted, 18.dp)
        }
    }
}

@Composable
fun ContactScreen(onBack: () -> Unit, onFail: (String) -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
            .padding(bottom = 30.dp)
    ) {
        PageHead("ارتباط با ما", onBack)
        Gap(14)
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(84.dp).clip(CircleShape).background(C.a.copy(alpha = 0.16f))
                    .border(1.dp, C.a.copy(alpha = 0.4f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Ico("chat", C.a, 38.dp) }
        }
        Gap(14)
        Text(
            "ما کنارتیم", color = C.fg, fontSize = 21.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Gap(6)
        Text(
            "از هر راهی که برات راحت‌تره با ما در ارتباط باش.", color = C.muted, fontSize = 13.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        Gap(24)
        ContactOption("chat", "پشتیبانی تلگرام", "گفتگوی مستقیم با پشتیبان") {
            if (!Reach.telegram(ctx, Reach.SUPPORT)) onFail("برنامه‌ای برای باز کردن لینک پیدا نشد")
        }
        Gap(12)
        ContactOption("wave", "کانال تلگرام", "اخبار و اطلاعیه‌ها") {
            if (!Reach.telegram(ctx, Reach.CHANNEL)) onFail("برنامه‌ای برای باز کردن لینک پیدا نشد")
        }
        Gap(12)
        ContactOption("mail", "ایمیل پشتیبانی", "ارسال توضیحات و تصویر") {
            if (!Reach.mail(ctx)) onFail("برنامه‌ی ایمیل پیدا نشد")
        }
        Gap(20)
        Text(
            "اگه مشکلی پیش اومد، یه اسکرین‌شات از مشکل و متن «لاگ اتصال» رو بفرست تا سریع‌تر بررسی بشه.",
            color = C.muted, fontSize = 12.sp, lineHeight = 19.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp)
        )
    }
}
