package com.velnora.app

/**
 * Server addresses and ports are never shown anywhere in the app (profile list, details, log,
 * notification, error messages), so people who receive a config cannot read the server from the screen.
 */
object Privacy {
    const val NOTE = "برای جلوگیری از سوءاستفاده، آدرس سرور و پورت نمایش داده نمی‌شه."

    private val hosts = HashSet<String>()
    private val v4 = Regex("\\b\\d{1,3}(?:\\.\\d{1,3}){3}(?::\\d{1,5})?\\b")
    private val v6 = Regex("\\[?(?:[0-9a-fA-F]{1,4}:){4,7}[0-9a-fA-F]{0,4}\\]?(?::\\d{1,5})?|\\[?(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{0,4}\\]?")
    private val portWord = Regex("(?i)\\b(port|remote|rport|lport)(\\s*[:=]?\\s*)\\d{2,5}\\b")
    private val family = Regex("\\[AF_INET6?\\]")
    private val domain = Regex("\\b(?:[a-zA-Z0-9-]+\\.)+(?:com|net|org|io|ir|me|info|xyz|site|online|app|co|cc|tv|top|vip|club|cloud|link|live|pro|dev|us|de|nl|fr|uk|ru|tr|ae|sg|hk|jp)\\b(?::\\d{1,5})?", RegexOption.IGNORE_CASE)

    /** Remembers the server names of a config so they can be hidden wherever they appear. */
    fun learn(configText: String) {
        for (m in Regex("(?m)^\\s*remote\\s+(\\S+)").findAll(configText)) {
            val h = m.groupValues[1].trim()
            if (h.length >= 3) synchronized(hosts) { hosts.add(h) }
        }
    }

    fun learnHost(h: String) {
        if (h.length >= 3) synchronized(hosts) { hosts.add(h) }
    }

    /** Replaces addresses (IPv4, IPv6, domain names) and ports with dots. */
    fun clean(s: String): String {
        if (s.isEmpty()) return s
        var t = s
        val known = synchronized(hosts) { hosts.toList() }
        for (h in known.sortedByDescending { it.length }) {
            t = t.replace(Regex(Regex.escape(h) + "(?::\\d{1,5})?", RegexOption.IGNORE_CASE), "•••")
        }
        t = family.replace(t, "")
        t = v4.replace(t, "•••")
        t = v6.replace(t, "•••")
        t = domain.replace(t, "•••")
        t = portWord.replace(t) { it.groupValues[1] + it.groupValues[2] + "•••" }
        return t
    }

    /** A profile name that is just an address would leak it, so it is hidden too. */
    fun name(n: String): String {
        val c = clean(n).trim()
        return if (c.isBlank() || c.replace("•", "").replace(".", "").isBlank()) "پروفایل" else c
    }
}
