package com.velnora.app

import android.app.Application
import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class VelnoraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Skin.apply(Prefs(this))
        EngineLoader.load(this)
        Notifier.init(this)
        NetWatch.start(this)
        Updater.schedule(this, Prefs(this).b("auto", true))
    }
}

/** Background refresh of subscription links. */
object Updater {
    private const val NAME = "velnora_sub_update"

    fun schedule(ctx: Context, on: Boolean) {
        val wm = WorkManager.getInstance(ctx)
        if (!on) {
            wm.cancelUniqueWork(NAME)
            return
        }
        val req = PeriodicWorkRequestBuilder<SubWorker>(12, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

class SubWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val store = ConfStore(applicationContext)
        for (s in store.subs()) {
            try {
                store.applySub(s.url, Sub.fetch(s.url))
            } catch (e: Exception) {
            }
        }
        return Result.success()
    }
}
