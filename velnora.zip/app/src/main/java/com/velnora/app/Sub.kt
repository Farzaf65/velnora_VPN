package com.velnora.app

import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL

/** Result of reading a subscription link. used/total are bytes, expire is epoch seconds; -1 = not given. */
class SubData(
    val title: String,
    val configs: List<Pair<String, String>>,
    val used: Long,
    val total: Long,
    val expire: Long
)

object Sub {
    fun isLink(t: String): Boolean = Regex("^https?://\\S+$").matches(t.trim())

    private fun decode(s: String): String? = try {
        val clean = s.replace(Regex("\\s"), "")
        if (clean.isEmpty()) null else String(Base64.decode(clean, Base64.DEFAULT), Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }

    fun split(t: String): List<String> {
        var text = t.trim()
        if (!Ovpn.looksLike(text)) {
            val d = decode(text)
            if (d != null && Ovpn.looksLike(d)) text = d
        }
        if (!Ovpn.looksLike(text)) return emptyList()
        val parts = Regex("(?m)^(?=\\s*client\\s*$)").split(text).filter { Ovpn.looksLike(it) }
        return if (parts.isEmpty()) listOf(text) else parts
    }

    private fun userInfo(h: String?): LongArray {
        val r = longArrayOf(-1, -1, -1)
        if (h == null) return r
        var up = 0L
        var down = 0L
        var seen = false
        for (kv in h.split(";")) {
            val p = kv.trim().split("=")
            if (p.size != 2) continue
            val n = p[1].trim().toDoubleOrNull()?.toLong() ?: continue
            when (p[0].trim().lowercase()) {
                "upload" -> { up = n; seen = true }
                "download" -> { down = n; seen = true }
                "total" -> r[1] = n
                "expire" -> r[2] = n
            }
        }
        if (seen) r[0] = up + down
        return r
    }

    private fun title(c: HttpURLConnection): String {
        val t = c.getHeaderField("Profile-Title")
        if (!t.isNullOrBlank()) {
            return if (t.startsWith("base64:")) decode(t.removePrefix("base64:")) ?: "" else t
        }
        val cd = c.getHeaderField("Content-Disposition") ?: return ""
        val m = Regex("filename\\*?=\"?([^\";]+)").find(cd) ?: return ""
        return m.groupValues[1].removeSuffix(".ovpn")
    }

    /** Blocking: call it away from the main thread. */
    fun fetch(url: String): SubData {
        val u = URL(url.trim())
        val c = u.openConnection() as HttpURLConnection
        if (!u.userInfo.isNullOrEmpty()) {
            c.setRequestProperty(
                "Authorization",
                "Basic " + Base64.encodeToString(java.net.URLDecoder.decode(u.userInfo, "UTF-8").toByteArray(), Base64.NO_WRAP)
            )
        }
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Velnora/0.1")
        try {
            if (c.responseCode == 401 || c.responseCode == 403) throw IllegalStateException("auth")
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP " + c.responseCode)
            val raw = c.inputStream.use { it.readBytes() }
            if (raw.size > 30_000_000) throw IllegalStateException("big")
            val ui = userInfo(c.getHeaderField("Subscription-Userinfo"))
            if (Pack.isZip(raw)) {
                val z = Pack.fromZip(raw)
                if (z.isEmpty()) throw IllegalStateException("format")
                return SubData(title(c), z, ui[0], ui[1], ui[2])
            }
            val list = split(String(raw, Charsets.UTF_8))
            if (list.isEmpty()) throw IllegalStateException("format")
            val configs = list.mapIndexed { i, t ->
                val host = Ovpn.parse(t)?.host ?: "server"
                (if (list.size > 1) host + " " + (i + 1) else host) to t
            }
            return SubData(title(c), configs, ui[0], ui[1], ui[2])
        } finally {
            c.disconnect()
        }
    }
}
