package com.velnora.app

import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL

/** Result of reading a subscription link. used/total are bytes, expire is epoch seconds; -1 = not given. */
class SubData(
    val title: String,
    val configs: List<Pair<String, String>>,
    val used: Long,
    val total: Long,
    val expire: Long
)

object Sub {
    fun isLink(t: String): Boolean = Regex("^https?://\\S+$").matches(t.trim())

    private fun decode(s: String): String? = try {
        val clean = s.replace(Regex("\\s"), "")
        if (clean.isEmpty()) null else String(Base64.decode(clean, Base64.DEFAULT), Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }

    fun split(t: String): List<String> {
        var text = t.trim()
        if (!Ovpn.looksLike(text)) {
            val d = decode(text)
            if (d != null && Ovpn.looksLike(d)) text = d
        }
        if (!Ovpn.looksLike(text)) return emptyList()
        val parts = Regex("(?m)^(?=\\s*client\\s*$)").split(text).filter { Ovpn.looksLike(it) }
        return if (parts.isEmpty()) listOf(text) else parts
    }

    internal fun userInfo(h: String?): LongArray {
        val r = longArrayOf(-1, -1, -1)
        if (h == null) return r
        var up = 0L
        var down = 0L
        var seen = false
        for (kv in h.split(";")) {
            val p = kv.trim().split("=")
            if (p.size != 2) continue
            val n = p[1].trim().toDoubleOrNull()?.toLong() ?: continue
            when (p[0].trim().lowercase()) {
                "upload" -> { up = n; seen = true }
                "download" -> { down = n; seen = true }
                "total" -> r[1] = n
                "expire" -> r[2] = n
            }
        }
        if (seen) r[0] = up + down
        return r
    }

    private fun title(c: HttpURLConnection): String {
        val t = c.getHeaderField("Profile-Title")
        if (!t.isNullOrBlank()) {
            return if (t.startsWith("base64:")) decode(t.removePrefix("base64:")) ?: "" else t
        }
        val cd = c.getHeaderField("Content-Disposition") ?: return ""
        val m = Regex("filename\\*?=\"?([^\";]+)").find(cd) ?: return ""
        return m.groupValues[1].removeSuffix(".ovpn")
    }

    /** Finds config texts in odd answers: JSON, a web page, one base64 block per line, a list of links. */
    private fun dig(body: String, depth: Int): List<String> {
        val direct = split(body)
        if (direct.isNotEmpty()) return direct
        val found = ArrayList<String>()
        val t = body.trim()
        if (t.startsWith("{") || t.startsWith("[")) {
            fun walk(o: Any?) {
                when (o) {
                    is org.json.JSONObject -> for (k in o.keys()) walk(o.opt(k))
                    is org.json.JSONArray -> for (i in 0 until o.length()) walk(o.opt(i))
                    is String -> found.addAll(split(o))
                }
            }
            try {
                walk(if (t.startsWith("{")) org.json.JSONObject(t) else org.json.JSONArray(t))
            } catch (e: Exception) {
            }
            if (found.isNotEmpty()) return found
        }
        if (t.contains("<") && t.contains(">")) {
            val plain = t.replace(Regex("(?is)<(script|style).*?</\\1>"), "")
                .replace(Regex("(?i)<br\\s*/?>"), "\n")
                .replace(Regex("<[^>]+>"), "")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
            val d = split(plain)
            if (d.isNotEmpty()) return d
        }
        val lines = t.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size in 2..60) {
            for (l in lines) found.addAll(split(l))
            if (found.isNotEmpty()) return found
        }
        if (depth == 0 && lines.size in 1..30 && lines.all { Regex("^https?://\\S+$").matches(it) }) {
            for (l in lines) {
                try {
                    found.addAll(dig(get(l, "Velnora/0.4").first, 1))
                } catch (e: Exception) {
                }
            }
        }
        return found
    }

    private fun get(url: String, agent: String): Triple<String, ByteArray, Pair<String, LongArray>> {
        val u = URL(url.trim())
        val c = u.openConnection() as HttpURLConnection
        if (!u.userInfo.isNullOrEmpty()) {
            c.setRequestProperty(
                "Authorization",
                "Basic " + Base64.encodeToString(java.net.URLDecoder.decode(u.userInfo, "UTF-8").toByteArray(), Base64.NO_WRAP)
            )
        }
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", agent)
        try {
            if (c.responseCode == 401 || c.responseCode == 403) throw IllegalStateException("auth")
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP " + c.responseCode)
            val raw = c.inputStream.use { it.readBytes() }
            if (raw.size > 30_000_000) throw IllegalStateException("big")
            return Triple(String(raw, Charsets.UTF_8), raw, title(c) to userInfo(c.getHeaderField("Subscription-Userinfo")))
        } finally {
            c.disconnect()
        }
    }

    /** Blocking: call it away from the main thread. */
    fun fetch(url: String): SubData {
        var last: Exception = IllegalStateException("format")
        for (agent in listOf("Velnora/0.4", "OpenVPN Connect/3.5.0 (Android)", "Mozilla/5.0 (Linux; Android 14)")) {
            try {
                val g = get(url, agent)
                val raw = g.second
                val ui = g.third.second
                val ttl = g.third.first
                if (Pack.isZip(raw)) {
                    val z = Pack.fromZip(raw)
                    if (z.isEmpty()) throw IllegalStateException("format")
                    return SubData(ttl, z, ui[0], ui[1], ui[2])
                }
                val list = dig(g.first, 0)
                if (list.isEmpty()) throw IllegalStateException("format")
                for (t in list) Privacy.learn(t)
                val base = ttl.ifBlank { "پروفایل" }
                val configs = list.mapIndexed { i, t -> (if (list.size > 1) base + " " + (i + 1) else base) to t }
                return SubData(ttl, configs, ui[0], ui[1], ui[2])
            } catch (e: IllegalStateException) {
                last = e
                if (e.message == "auth" || (e.message ?: "").startsWith("HTTP 4")) break
            } catch (e: java.io.IOException) {
                last = e
                break
            }
        }
        throw last
    }
}
