package com.velnora.app

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

/** What we can read from an .ovpn file without connecting. */
class OvpnInfo(
    val host: String,
    val port: String,
    val proto: String,
    val needsAuth: Boolean,
    val keyEncrypted: Boolean,
    val expiresAt: Long?,
    val cipher: String,
    val authAlg: String = "",
    val tls: String = "",
    val remotes: Int = 1
)

object Ovpn {
    private val block = Regex("(?s)<([A-Za-z][A-Za-z0-9-]*)>(.*?)</\\1>")
    private val pem = Regex("-----BEGIN CERTIFICATE-----[\\s\\S]*?-----END CERTIFICATE-----")

    fun looksLike(t: String): Boolean = Regex("(?m)^\\s*remote\\s+\\S+").containsMatchIn(t)

    fun parse(text: String): OvpnInfo? {
        val blocks = HashMap<String, String>()
        for (m in block.findAll(text)) blocks[m.groupValues[1].lowercase()] = m.groupValues[2]
        val body = block.replace(text, "")

        var host = ""
        var port = "1194"
        var remotePort = ""
        var proto = "udp"
        var remoteProto = ""
        var auth = false
        var askpass = false
        var cipher = ""
        var authAlg = ""
        var tls = ""
        var remotes = 0
        for (raw in body.lines()) {
            val l = raw.trim()
            if (l.isEmpty() || l.startsWith("#") || l.startsWith(";")) continue
            val p = l.split(Regex("\\s+"))
            when (p[0].lowercase()) {
                "remote" -> if (p.size >= 2) {
                    remotes++
                    if (host.isEmpty()) {
                        host = p[1]
                        if (p.size >= 3) remotePort = p[2]
                        if (p.size >= 4) remoteProto = p[3]
                    }
                }
                "auth" -> if (p.size >= 2 && authAlg.isEmpty()) authAlg = p[1]
                "tls-crypt", "tls-crypt-v2", "tls-auth" -> if (tls.isEmpty()) tls = p[0].lowercase()
                "port" -> if (p.size >= 2) port = p[1]
                "proto" -> if (p.size >= 2) proto = p[1]
                "auth-user-pass" -> auth = true
                "askpass" -> askpass = true
                "cipher", "data-ciphers" -> if (p.size >= 2 && cipher.isEmpty()) cipher = p[1]
            }
        }
        if (host.isEmpty()) return null
        if (blocks.containsKey("auth-user-pass")) auth = false
        if (tls.isEmpty()) {
            for (t in listOf("tls-crypt-v2", "tls-crypt", "tls-auth")) if (blocks.containsKey(t)) { tls = t; break }
        }
        if (remotes == 0) remotes = 1
        val enc = askpass || (blocks["key"]?.contains("ENCRYPTED") == true)

        var exp: Long? = null
        try {
            val c = blocks["cert"]
            val m = if (c != null) pem.find(c) else null
            if (m != null) {
                val cert = CertificateFactory.getInstance("X.509")
                    .generateCertificate(ByteArrayInputStream(m.value.toByteArray())) as X509Certificate
                exp = cert.notAfter.time
            }
        } catch (e: Exception) {
        }
        return OvpnInfo(
            host, if (remotePort.isNotEmpty()) remotePort else port,
            (if (remoteProto.isNotEmpty()) remoteProto else proto).lowercase(),
            auth, enc, exp, cipher, authAlg, tls, remotes
        )
    }

    /**
     * Applies the user's protocol choice ("udp" or "tcp") by rewriting the proto lines.
     * The server must really listen on that protocol, otherwise the connection fails.
     */
    fun withProto(text: String, proto: String): String {
        if (proto != "udp" && proto != "tcp") return text
        val out = ArrayList<String>()
        var seen = false
        for (raw in text.lines()) {
            val l = raw.trim()
            val p = l.split(Regex("\\s+"))
            when {
                p[0].lowercase() == "proto" && p.size >= 2 -> { out.add("proto $proto"); seen = true }
                p[0].lowercase() == "remote" && p.size >= 4 -> out.add(p.take(3).joinToString(" ") + " " + proto)
                proto == "tcp" && p[0].lowercase() == "explicit-exit-notify" -> {}
                else -> out.add(raw)
            }
        }
        if (!seen) out.add(0, "proto $proto")
        return out.joinToString("\n")
    }
}
