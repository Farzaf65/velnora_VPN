package com.velnora.app

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AddSheet(onDismiss: () -> Unit, onFile: () -> Unit, onText: (String) -> Unit) {
    val ctx = LocalContext.current
    var t by remember { mutableStateOf("") }
    val kind = when {
        t.isBlank() -> ""
        Sub.isLink(t) -> "لینک سابسکریپشن شناسایی شد"
        Ovpn.looksLike(t) -> "کانفیگ OpenVPN شناسایی شد"
        else -> "فرمت شناخته نشد"
    }
    val ok = kind.startsWith("لینک") || kind.startsWith("کانفیگ")
    Sheet(onDismiss, "افزودن") {
        Btn("انتخاب فایل .ovpn", primary = false) { onFile() }
        Gap(14)
        Text("یا لینک سابسکریپشن و متن کانفیگ رو اینجا بچسبون", color = C.muted, fontSize = 12.sp)
        Gap(8)
        Field(t, { t = it }, "https://… یا client / remote …", lines = 5)
        if (kind.isNotEmpty()) {
            Gap(8)
            Text(kind, color = if (ok) C.ok else C.bad, fontSize = 12.5.sp)
        }
        Gap(12)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("از کلیپ‌بورد", primary = false, modifier = Modifier.weight(1f)) {
                try {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    t = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString() ?: ""
                } catch (e: Exception) {
                }
            }
            Btn("افزودن", modifier = Modifier.weight(1f)) { if (ok) onText(t.trim()) }
        }
    }
}

@Composable
fun AuthSheet(name: String, onDismiss: () -> Unit, onOk: (String, String, Boolean) -> Unit) {
    var u by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var keep by remember { mutableStateOf(true) }
    Sheet(onDismiss, "ورود به «$name»") {
        Text("این کانفیگ نام کاربری و رمز می‌خواد.", color = C.muted, fontSize = 12.5.sp)
        Gap(12)
        Field(u, { u = it }, "نام کاربری")
        Gap(8)
        Field(p, { p = it }, "رمز عبور", pass = true)
        Gap(10)
        Row(
            Modifier.fillMaxWidth().clickable { keep = !keep }.padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(20.dp).background(if (keep) C.a else C.surf2, androidx.compose.foundation.shape.RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) { if (keep) Ico("check", C.fg, 14.dp) }
            GapW(10)
            Text("ذخیره‌ی رمزنگاری‌شده روی همین گوشی", color = C.fg, fontSize = 13.sp)
        }
        Gap(12)
        Btn("اتصال") { if (u.isNotBlank()) onOk(u.trim(), p, keep) }
    }
}

@Composable
fun KeySheet(name: String, onDismiss: () -> Unit, onOk: (String, Boolean) -> Unit) {
    var p by remember { mutableStateOf("") }
    var keep by remember { mutableStateOf(true) }
    Sheet(onDismiss, "رمز کلید «$name»") {
        Text("کلید این کانفیگ رمزدار است.", color = C.muted, fontSize = 12.5.sp)
        Gap(12)
        Field(p, { p = it }, "رمز کلید", pass = true)
        Gap(10)
        Row(
            Modifier.fillMaxWidth().clickable { keep = !keep }.padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(20.dp).background(if (keep) C.a else C.surf2, androidx.compose.foundation.shape.RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) { if (keep) Ico("check", C.fg, 14.dp) }
            GapW(10)
            Text("ذخیره‌ی رمزنگاری‌شده روی همین گوشی", color = C.fg, fontSize = 13.sp)
        }
        Gap(12)
        Btn("اتصال") { if (p.isNotEmpty()) onOk(p, keep) }
    }
}

@Composable
fun DetailSheet(
    c: Conf, saved: Boolean, onDismiss: () -> Unit, onForget: () -> Unit, onDelete: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var show by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(c.name) }
    var u by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    val e = expInfo(c.expiresAt)
    Sheet(onDismiss, "ویرایش سرور") {
        Field(name, { name = it }, "نام سرور")
        Gap(12)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("آدرس", color = C.muted, fontSize = 12.5.sp, modifier = Modifier.weight(1f))
            Text(if (show) "\u200E" + c.host else "••••••••", color = C.fg, fontSize = 13.sp)
            GapW(10)
            Box(Modifier.clickable { show = !show }.padding(4.dp)) {
                Ico(if (show) "eyeoff" else "eye", C.muted, 20.dp)
            }
        }
        Gap(10)
        Row {
            Text("پورت و پروتکل", color = C.muted, fontSize = 12.5.sp, modifier = Modifier.weight(1f))
            Text(c.proto.uppercase() + " · " + fa(c.port), color = C.fg, fontSize = 13.sp)
        }
        Gap(10)
        Row {
            Text("اعتبار", color = C.muted, fontSize = 12.5.sp, modifier = Modifier.weight(1f))
            Text(e.first, color = e.second, fontSize = 13.sp)
        }
        if (c.needsAuth) {
            Gap(14)
            Text(
                if (saved) "نام کاربری و رمز ذخیره شده؛ برای تغییر، مقدار جدید بنویس" else "نام کاربری و رمز (اختیاری)",
                color = C.muted, fontSize = 12.sp
            )
            Gap(8)
            Field(u, { u = it }, "نام کاربری")
            Gap(8)
            Field(p, { p = it }, "رمز عبور", pass = true)
        }
        Gap(14)
        Btn("ذخیره") { onSave(name, u.trim(), p) }
        Gap(8)
        if (saved) {
            Btn("پاک کردن رمزهای ذخیره‌شده", primary = false) { onForget() }
            Gap(8)
        }
        Btn("حذف سرور", primary = false, danger = true) { onDelete() }
    }
}
