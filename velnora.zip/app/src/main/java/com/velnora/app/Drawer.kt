package com.velnora.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MenuItem(val id: Int, val icon: String, val title: String, val sub: String = "")

/** Side menu that slides in from the start edge (the right side in Persian). */
@Composable
fun Drawer(open: Boolean, items: List<MenuItem>, onPick: (Int) -> Unit, onClose: () -> Unit) {
    val none = remember { MutableInteractionSource() }
    AnimatedVisibility(open, enter = fadeIn(tween(180)), exit = fadeOut(tween(160))) {
        Box(
            Modifier.fillMaxSize().background(Color(0x99000000)).clickable(none, null) { onClose() }
        )
    }
    AnimatedVisibility(
        open,
        enter = slideInHorizontally(tween(240)) { it },
        exit = slideOutHorizontally(tween(200)) { it }
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterStart) {
            val s = RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp)
            // In a right-to-left layout "start" is the right edge, so this panel sits on the right.
            Column(
                Modifier.fillMaxHeight().width(290.dp).clip(s).background(C.surf).border(1.dp, C.line, s)
                    .clickable(none, null) {}
                    .systemBarsPadding().verticalScroll(rememberScrollState()).padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.velnora_logo), null, Modifier.size(46.dp).clip(RoundedCornerShape(13.dp)))
                    GapW(12)
                    Column {
                        Text("VELNORA", color = C.fg, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("کلاینت OpenVPN", color = C.muted, fontSize = 12.sp)
                    }
                }
                Gap(22)
                for (m in items) {
                    Press(Modifier.fillMaxWidth(), 18.dp, { onPick(m.id) }) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(C.a.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) { Ico(m.icon, C.a, 20.dp) }
                            GapW(12)
                            Column(Modifier.weight(1f)) {
                                Text(m.title, color = C.fg, fontSize = 14.5.sp)
                                if (m.sub.isNotBlank()) Text(m.sub, color = C.muted, fontSize = 11.5.sp)
                            }
                        }
                    }
                }
                Gap(16)
                Text("ولنورا · نسخه ۰٫۵", color = C.muted, fontSize = 12.sp, modifier = Modifier.padding(start = 10.dp))
            }
        }
    }
}
