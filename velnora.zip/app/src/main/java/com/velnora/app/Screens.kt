package com.velnora.app

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** The route picture: phone at the bottom, the chosen server at the top, a line between them. */
@Composable
fun Route(state: VState, server: String?) {
    val tr = rememberInfiniteTransition(label = "route")
    val ph by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "ph")
    val col = when (state) {
        VState.On -> C.ok
        VState.Connecting -> C.a
        VState.Failed -> C.bad
        VState.Off -> C.muted
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            server ?: "سروری انتخاب نشده", color = if (server == null) C.muted else C.fg,
            fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1
        )
        Canvas(Modifier.fillMaxWidth().height(150.dp)) {
            val x = size.width / 2f
            val top = Offset(x, 14.dp.toPx())
            val bot = Offset(x, size.height - 14.dp.toPx())
            val wd = 3.dp.toPx()
            if (state == VState.Connecting) {
                drawLine(
                    col, bot, top, wd, StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 20f), -ph * 38f)
                )
            } else if (state == VState.On) {
                drawLine(
                    Brush.verticalGradient(listOf(C.ok, C.a), top.y, bot.y), top, bot, wd, StrokeCap.Round
                )
                val y = bot.y - (bot.y - top.y) * ph
                drawCircle(C.ok.copy(alpha = 0.25f), 11.dp.toPx(), Offset(x, y))
                drawCircle(C.ok, 4.dp.toPx(), Offset(x, y))
            } else {
                drawLine(
                    col.copy(alpha = 0.5f), bot, top, wd, StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 18f), 0f)
                )
            }
            drawCircle(col.copy(alpha = 0.18f), 14.dp.toPx(), top)
            drawCircle(col, 6.dp.toPx(), top, style = Stroke(2.dp.toPx()))
            drawCircle(col.copy(alpha = 0.18f), 14.dp.toPx(), bot)
            drawCircle(col, 6.dp.toPx(), bot)
        }
        Text("گوشی تو", color = C.muted, fontSize = 12.sp)
    }
}

private val COUNTRIES = listOf(
    "germany" to "🇩🇪 آلمان", "deutschland" to "🇩🇪 آلمان", "turkey" to "🇹🇷 ترکیه", "turkiye" to "🇹🇷 ترکیه",
    "france" to "🇫🇷 فرانسه", "netherlands" to "🇳🇱 هلند", "uk" to "🇬🇧 بریتانیا", "united kingdom" to "🇬🇧 بریتانیا",
    "usa" to "🇺🇸 آمریکا", "united states" to "🇺🇸 آمریکا", "canada" to "🇨🇦 کانادا", "finland" to "🇫🇮 فنلاند",
    "sweden" to "🇸🇪 سوئد", "norway" to "🇳🇴 نروژ", "uae" to "🇦🇪 امارات", "emirates" to "🇦🇪 امارات",
    "india" to "🇮🇳 هند", "japan" to "🇯🇵 ژاپن", "singapore" to "🇸🇬 سنگاپور", "russia" to "🇷🇺 روسیه",
    "poland" to "🇵🇱 لهستان", "italy" to "🇮🇹 ایتالیا", "spain" to "🇪🇸 اسپانیا", "switzerland" to "🇨🇭 سوئیس",
    "armenia" to "🇦🇲 ارمنستان", "iran" to "🇮🇷 ایران", "iraq" to "🇮🇶 عراق", "pakistan" to "🇵🇰 پاکستان",
    "saudi" to "🇸🇦 عربستان", "afghanistan" to "🇦🇫 افغانستان", "ukraine" to "🇺🇦 اوکراین", "romania" to "🇷🇴 رومانی"
)

/** Location is read from the server name only; no outside lookup, so it can be unknown. */
fun placeOf(name: String): String? {
    val n = name.lowercase()
    for ((k, v) in COUNTRIES) if (n.contains(k)) return v
    return null
}

fun pingText(p: Long?): Pair<String, Color> = when {
    p == null -> "—" to C.muted
    p < 0 -> "بی‌پاسخ" to C.bad
    p < 150 -> fa(p) + " ms" to C.ok
    p < 400 -> fa(p) + " ms" to C.warn
    else -> fa(p) + " ms" to C.bad
}

fun fmtSpeed(b: Long): String {
    if (b < 0) return "—"
    return if (b >= 1048576) fa("%.1f".format(b / 1048576.0)) + " MB/s" else fa("%.0f".format(b / 1024.0)) + " KB/s"
}

fun fmtAgo(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "همین حالا"
        m < 60 -> fa(m) + " دقیقه پیش"
        m < 1440 -> fa(m / 60) + " ساعت پیش"
        else -> fa(m / 1440) + " روز پیش"
    }
}

@Composable
fun NavBar(tab: Int, onTab: (Int) -> Unit, modifier: Modifier) {
    val s = RoundedCornerShape(26.dp)
    Row(
        modifier.navigationBarsPadding().padding(bottom = 12.dp).clip(s).background(C.surf).border(1.dp, C.line, s)
            .padding(5.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        for ((i, p) in listOf("خانه" to "bolt", "سرورها" to "file").withIndex()) {
            val on = tab == i
            Press(Modifier, 22.dp, { onTab(i) }) {
                Row(
                    Modifier.then(if (on) Modifier.background(Brush.horizontalGradient(listOf(C.a, C.b))) else Modifier)
                        .padding(horizontal = 22.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Ico(p.second, if (on) C.fg else C.muted, 18.dp)
                    GapW(8)
                    Text(p.first, color = if (on) C.fg else C.muted, fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun Mini(label: String, value: String, col: Color, modifier: Modifier) {
    Column(modifier.card(18.dp).padding(12.dp)) {
        Text(label, color = C.muted, fontSize = 11.sp)
        Gap(4)
        Text(value, color = col, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun HomeScreen(
    confs: List<Conf>, sel: String?, state: VState, note: String, since: Long,
    down: Long, up: Long, sub: Subscr?, last: String?, measuring: Boolean,
    onPick: (String) -> Unit, onConnect: () -> Unit, onMenu: () -> Unit, onFastest: () -> Unit, onSubs: () -> Unit
) {
    val cur = confs.firstOrNull { it.id == sel }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(state) {
        while (state == VState.On) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val dur = if (state == VState.On && since > 0) {
        val t = ((now - since) / 1000).coerceAtLeast(0)
        fa("%02d:%02d:%02d".format(t / 3600, (t % 3600) / 60, t % 60))
    } else "—"
    val stText = when (state) {
        VState.Off -> "قطع"
        VState.Connecting -> "در حال اتصال"
        VState.On -> "وصل"
        VState.Failed -> "ناموفق"
    }
    val stCol = when (state) {
        VState.On -> C.ok
        VState.Failed -> C.bad
        VState.Connecting -> C.a
        VState.Off -> C.muted
    }
    val e = if (cur != null) expInfo(cur.expiresAt) else ("—" to C.muted)

    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundBtn("menu", onMenu)
                GapW(10)
                Image(painterResource(R.drawable.velnora_logo), null, Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)))
                GapW(10)
                Text("VELNORA", color = C.fg, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Box(Modifier.weight(1f))
                RoundBtn("link", onSubs)
            }
        }
        item { Route(state, cur?.name) }
        if (cur != null) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)) {
                    Chip(cur.proto.uppercase() + " · " + fa(cur.port), C.a)
                    if (cur.cipher.isNotBlank()) Chip("\u200E" + cur.cipher.take(16), C.muted)
                    if (cur.tls.isNotBlank()) Chip("\u200E" + cur.tls, C.muted)
                }
            }
        }
        item {
            Btn(
                when (state) {
                    VState.Off, VState.Failed -> "اتصال"
                    VState.Connecting -> "لغو اتصال"
                    VState.On -> "قطع اتصال"
                },
                primary = state == VState.Off || state == VState.Failed,
                danger = state == VState.On,
                onClick = onConnect
            )
        }
        if (note.isNotBlank()) {
            item { Text(note, color = C.bad, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Mini("مدت اتصال", dur, C.fg, Modifier.weight(1f))
                Mini("دانلود ↓", fmtSpeed(down), C.fg, Modifier.weight(1f))
                Mini("آپلود ↑", fmtSpeed(up), C.fg, Modifier.weight(1f))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().card().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("اشتراک", color = C.fg, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Chip(e.first, e.second)
                }
                Gap(10)
                if (sub != null && sub.total > 0 && sub.used >= 0) {
                    val f = (sub.used.toFloat() / sub.total.toFloat()).coerceIn(0f, 1f)
                    Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(C.surf2)) {
                        Box(
                            Modifier.fillMaxWidth(f).height(6.dp).clip(CircleShape)
                                .background(Brush.horizontalGradient(listOf(C.a, C.b)))
                        )
                    }
                    Gap(8)
                    Text(
                        fmtBytes((sub.total - sub.used).coerceAtLeast(0)) + " باقی‌مانده از " + fmtBytes(sub.total),
                        color = C.fg, fontSize = 13.sp
                    )
                } else {
                    Text(
                        if (sub != null) "سرویس‌دهنده اطلاعات حجم رو اعلام نکرده" else "این سرور از لینک اشتراک نیست",
                        color = C.muted, fontSize = 12.5.sp
                    )
                }
                Gap(10)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(stCol)
                    GapW(8)
                    Text(
                        "آخرین اتصال: " + (last ?: "هنوز اتصالی انجام نشده"),
                        color = C.muted, fontSize = 12.sp
                    )
                }
            }
        }
        if (confs.isNotEmpty()) {
            item {
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("دسترسی سریع", color = C.fg, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Press(Modifier, 14.dp, onFastest) {
                        Row(
                            Modifier.background(C.surf2).padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Ico("fast", C.a, 15.dp)
                            GapW(6)
                            Text(if (measuring) "در حال سنجش…" else "سریع‌ترین", color = C.fg, fontSize = 12.5.sp)
                        }
                    }
                }
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(confs.take(8), key = { it.id }) { c ->
                        val on = c.id == sel
                        Press(Modifier, 16.dp, { onPick(c.id) }) {
                            Row(
                                Modifier.background(if (on) C.surf2 else C.surf)
                                    .border(if (on) 1.5.dp else 1.dp, if (on) C.a else C.line, RoundedCornerShape(16.dp))
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(placeOf(c.name)?.substringBefore(' ') ?: "•", fontSize = 14.sp)
                                GapW(8)
                                Text(c.name, color = C.fg, fontSize = 13.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        item { Gap(96) }
    }
}

@Composable
private fun ServerCard(c: Conf, picked: Boolean, ping: Long?, onPick: () -> Unit, onMore: () -> Unit) {
    val e = expInfo(c.expiresAt)
    val p = pingText(ping)
    val place = placeOf(c.name)
    val s = RoundedCornerShape(22.dp)
    val avail = when {
        c.proto.startsWith("udp") && (ping == null || ping < 0) -> "پینگ UDP قابل اندازه‌گیری نیست" to C.muted
        ping == null -> "اندازه‌گیری نشده" to C.muted
        ping < 0 -> "پاسخ نمی‌ده" to C.bad
        else -> "در دسترس" to C.ok
    }
    Press(Modifier.fillMaxWidth(), 22.dp, onPick) {
        Row(
            Modifier.fillMaxWidth().background(C.surf).border(if (picked) 1.5.dp else 1.dp, if (picked) C.a else C.line, s)
        ) {
            Box(Modifier.width(5.dp).height(104.dp).background(if (picked) C.a else avail.second.copy(alpha = 0.7f)))
            Column(Modifier.weight(1f).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(c.name, color = C.fg, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
                    Text(p.first, color = p.second, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
                Gap(4)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(avail.second)
                    GapW(6)
                    Text(
                        (if (place != null) place + " · " else "") + avail.first,
                        color = C.muted, fontSize = 12.sp, maxLines = 1
                    )
                }
                Gap(10)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Chip(c.proto.uppercase() + " · " + fa(c.port), C.a)
                    Chip(e.first, e.second)
                    if (c.needsAuth || c.keyEnc) Chip("رمز", C.warn) else if (c.subId != null) Chip("اشتراک", C.b)
                }
            }
            Press(Modifier.padding(top = 8.dp, end = 4.dp).size(40.dp), 20.dp, onMore) {
                Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) { Ico("dots", C.muted, 20.dp) }
            }
        }
    }
}

@Composable
fun ServersScreen(
    confs: List<Conf>, sel: String?, pings: Map<String, Long>, measuring: Boolean,
    onPick: (String) -> Unit, onMore: (Conf) -> Unit, onAdd: () -> Unit, onSubs: () -> Unit, onPing: () -> Unit,
    onMenu: () -> Unit, onFastest: () -> Unit
) {
    var q by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(0) }
    val list = confs.filter { q.isBlank() || it.name.contains(q.trim(), true) || it.host.contains(q.trim(), true) }
        .let { l ->
            when (sort) {
                1 -> l.sortedBy { pings[it.id].let { p -> if (p == null || p < 0) Long.MAX_VALUE else p } }
                2 -> l.sortedBy { it.expiresAt ?: Long.MAX_VALUE }
                else -> l.sortedBy { it.name.lowercase() }
            }
        }
    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundBtn("menu", onMenu)
                GapW(12)
                Text("سرورها", color = C.fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                GapW(8)
                Text(fa(confs.size.toLong()), color = C.muted, fontSize = 13.sp)
                Box(Modifier.weight(1f))
                RoundBtn("link", onSubs)
                GapW(8)
                RoundBtn("plus", onAdd)
            }
        }
        item { Field(q, { q = it }, "جست‌وجوی سرور") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                for ((i, n) in listOf("نام", "پینگ", "اعتبار").withIndex()) {
                    Press(Modifier, 14.dp, { sort = i }) {
                        Box(
                            Modifier.background(if (sort == i) C.a.copy(alpha = 0.25f) else C.surf2)
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                        ) { Text(n, color = if (sort == i) C.fg else C.muted, fontSize = 12.5.sp) }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Press(Modifier.weight(1f), 14.dp, onFastest) {
                    Row(
                        Modifier.fillMaxWidth().background(C.surf2).padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
                    ) {
                        Ico("fast", C.a, 16.dp)
                        GapW(6)
                        Text("انتخاب سریع‌ترین", color = C.fg, fontSize = 12.5.sp)
                    }
                }
                Press(Modifier.weight(1f), 14.dp, onPing) {
                    Row(
                        Modifier.fillMaxWidth().background(C.surf2).padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
                    ) {
                        Ico("refresh", C.a, 15.dp)
                        GapW(6)
                        Text(if (measuring) "در حال اندازه‌گیری…" else "سنجش پینگ", color = C.fg, fontSize = 12.5.sp)
                    }
                }
            }
        }
        if (list.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().card().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Ico("file", C.muted, 30.dp)
                    Gap(10)
                    Text(
                        if (confs.isEmpty()) "هنوز سروری نداری. با «+» فایل یا لینک اشتراک اضافه کن." else "موردی پیدا نشد.",
                        color = C.muted, fontSize = 13.sp, textAlign = TextAlign.Center
                    )
                }
            }
        }
        items(list, key = { it.id }) { c -> ServerCard(c, c.id == sel, pings[c.id], { onPick(c.id) }, { onMore(c) }) }
        item { Gap(96) }
    }
}

@Composable
fun SubsScreen(
    subs: List<Subscr>, busy: Boolean, onBack: () -> Unit, onAdd: () -> Unit,
    onUpdate: (Subscr) -> Unit, onDelete: (Subscr) -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundBtn("back", onBack)
                GapW(12)
                Text("سابسکریپشن‌ها", color = C.fg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.weight(1f))
                RoundBtn("plus", onAdd)
            }
        }
        item {
            Text(
                "لینک سابسکریپشن رو بده تا کانفیگ‌ها خودکار گرفته بشن و هر وقت خواستی بروز بشن.",
                color = C.muted, fontSize = 12.5.sp, lineHeight = 20.sp
            )
        }
        if (busy) {
            item { Text("در حال دریافت…", color = C.a, fontSize = 13.sp) }
        }
        items(subs, key = { it.id }) { s ->
            val e = expInfo(if (s.expire > 0) s.expire * 1000L else null)
            Column(Modifier.fillMaxWidth().card().padding(16.dp)) {
                Text(
                    s.title.ifBlank { "سابسکریپشن" }, color = C.fg, fontSize = 15.sp,
                    fontWeight = FontWeight.Bold, maxLines = 1
                )
                Gap(4)
                Text("‎" + s.url.take(48) + if (s.url.length > 48) "…" else "", color = C.muted, fontSize = 11.sp, maxLines = 1)
                Gap(12)
                if (s.total > 0 && s.used >= 0) {
                    val f = (s.used.toFloat() / s.total.toFloat()).coerceIn(0f, 1f)
                    Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(C.surf2)) {
                        Box(
                            Modifier.fillMaxWidth(f).height(6.dp).clip(CircleShape)
                                .background(Brush.horizontalGradient(listOf(C.a, C.b)))
                        )
                    }
                    Gap(6)
                    Text(
                        fmtBytes(s.used) + " از " + fmtBytes(s.total) + " مصرف شده",
                        color = C.muted, fontSize = 12.sp
                    )
                    Gap(8)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip(e.first, e.second)
                }
                Gap(12)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn("بروزرسانی", primary = false, modifier = Modifier.weight(1f)) { onUpdate(s) }
                    Btn("حذف", primary = false, danger = true, modifier = Modifier.weight(1f)) { onDelete(s) }
                }
            }
        }
        if (subs.isEmpty() && !busy) {
            item {
                Column(
                    Modifier.fillMaxWidth().card().padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Ico("link", C.muted, 30.dp)
                    Gap(10)
                    Text("هنوز لینکی اضافه نکردی.", color = C.muted, fontSize = 13.sp)
                }
            }
        }
        item { Gap(24) }
    }
}
