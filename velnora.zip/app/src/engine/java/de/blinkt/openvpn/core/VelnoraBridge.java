package de.blinkt.openvpn.core;

import android.content.Context;

/** Lives in the engine's package so it can reach its package-private start-up method. */
public class VelnoraBridge {
    public static void statusInit(Context c) {
        new StatusListener().init(c);
    }
}
