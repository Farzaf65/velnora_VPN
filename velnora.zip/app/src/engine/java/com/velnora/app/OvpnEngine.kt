package com.velnora.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import de.blinkt.openvpn.core.ConfigParser
import de.blinkt.openvpn.core.ConnectionStatus
import de.blinkt.openvpn.core.IOpenVPNServiceInternal
import de.blinkt.openvpn.core.OpenVPNService
import de.blinkt.openvpn.core.ProfileManager
import de.blinkt.openvpn.core.StatusListener
import de.blinkt.openvpn.core.VPNLaunchHelper
import de.blinkt.openvpn.core.VpnStatus
import java.io.StringReader

/**
 * Real OpenVPN engine (ics-openvpn). This file is compiled only when the build is started with
 * -Pengine=on. Everything shown in the app comes from the callbacks below.
 */
class OvpnEngine : Engine {
    override val ready = true
    override val selfReconnect = true

    override fun init(ctx: Context) {
        VpnStatus.initLogCache(ctx.cacheDir)
        StatusListener().init(ctx)
        VpnStatus.addStateListener(object : VpnStatus.StateListener {
            override fun updateState(
                state: String?, logmessage: String?, localizedResId: Int, level: ConnectionStatus?, intent: Intent?
            ) {
                when (level) {
                    ConnectionStatus.LEVEL_CONNECTED -> VpnCtl.connected()
                    ConnectionStatus.LEVEL_NOTCONNECTED -> VpnCtl.off()
                    ConnectionStatus.LEVEL_AUTH_FAILED -> VpnCtl.fail("نام کاربری یا رمز اشتباه است")
                    ConnectionStatus.LEVEL_NONETWORK -> VpnCtl.fail("اینترنت قطع است")
                    ConnectionStatus.LEVEL_WAITING_FOR_USER_INPUT -> VpnCtl.fail("اطلاعات ورود لازم است")
                    null -> {}
                    else -> VpnCtl.connecting()
                }
            }

            override fun setConnectedVPN(uuid: String?) {}
        })
        VpnStatus.addLogListener(object : VpnStatus.LogListener {
            override fun newLog(logItem: de.blinkt.openvpn.core.LogItem?) {
                if (logItem == null) return
                try {
                    val t = logItem.getString(ctx)
                    // never copy password lines into the log
                    if (!t.contains("password", true)) VpnCtl.log("[OpenVPN] " + t)
                } catch (e: Exception) {
                }
            }
        })
        VpnStatus.addByteCountListener(object : VpnStatus.ByteCountListener {
            override fun updateByteCount(inBytes: Long, outBytes: Long, diffIn: Long, diffOut: Long) {
                // the engine reports every 2 seconds
                VpnCtl.speed(diffIn / 2, diffOut / 2)
            }
        })
    }

    override fun start(
        ctx: Context, name: String, text: String, user: String?, pass: String?, keyPass: String?, opts: ConnOpts
    ) {
        try {
            val cp = ConfigParser()
            cp.parseConfig(StringReader(text))
            val vp = cp.convertProfile()
            vp.mName = name
            if (user != null) {
                vp.mUsername = user
                vp.mPassword = pass ?: ""
            }
            if (keyPass != null) vp.mKeyPassword = keyPass
            if (opts.dns1.isNotBlank()) {
                vp.mOverrideDNS = true
                vp.mDNS1 = opts.dns1
                vp.mDNS2 = opts.dns2
            }
            if (opts.splitMode != 0 && opts.splitApps.isNotEmpty()) {
                vp.mAllowedAppsVpn = HashSet(opts.splitApps)
                vp.mAllowedAppsVpnAreDisallowed = opts.splitMode == 2
            }
            val pm = ProfileManager.getInstance(ctx)
            pm.addProfile(vp)
            pm.saveProfile(ctx, vp)
            pm.saveProfileList(ctx)
            VPNLaunchHelper.startOpenVpn(vp, ctx, "Velnora", true)
        } catch (e: Exception) {
            VpnCtl.fail("کانفیگ خونده نشد: " + (e.message ?: ""))
        }
    }

    override fun stop(ctx: Context) {
        ProfileManager.setConntectedVpnProfileDisconnected(ctx)
        val i = Intent(ctx, OpenVPNService::class.java)
        i.action = OpenVPNService.START_SERVICE
        ctx.bindService(i, object : ServiceConnection {
            override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
                try {
                    IOpenVPNServiceInternal.Stub.asInterface(b).stopVPN(false)
                } catch (e: Exception) {
                }
                ctx.unbindService(this)
            }

            override fun onServiceDisconnected(n: ComponentName?) {}
        }, Context.BIND_AUTO_CREATE)
    }
}
