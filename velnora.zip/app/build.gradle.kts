plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val engineOn = providers.gradleProperty("engine").orNull == "on"

android {
    namespace = "com.velnora.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.velnora.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 6
        versionName = "0.5.1"
    }

    signingConfigs {
        // Fixed debug key kept in the project, so every build has the same signature.
        getByName("debug") {
            storeFile = rootProject.file("velnora-debug.keystore")
            storePassword = "android"
            keyAlias = "velnora"
            keyPassword = "android"
        }
        create("release") {
            val ks = System.getenv("KEYSTORE_FILE")
            if (ks != null && File(ks).exists()) {
                storeFile = File(ks)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = "dnschanger"
                keyPassword = System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    sourceSets {
        if (engineOn) {
            getByName("main").java.srcDir("src/engine/java")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        // The OpenVPN program is started from a file, so the native libraries must be extracted.
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    if (engineOn) {
        implementation(project(":ics-openvpn:main"))
    }
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
