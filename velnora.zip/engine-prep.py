#!/usr/bin/env python3
"""Reads the versions the OpenVPN engine project uses and aligns this project with them.
Run by the build workflow after the engine was cloned into ics-openvpn/. Prints what it found."""
import os, re, sys, shutil, glob

try:
    import tomllib
except Exception:  # very old python
    tomllib = None

proj = sys.argv[1]
eng = os.path.join(proj, "ics-openvpn")
root_b = os.path.join(proj, "build.gradle.kts")
app_b = os.path.join(proj, "app", "build.gradle.kts")

def say(*a):
    print("INFO", *a, flush=True)

for f in (root_b, app_b):
    if not os.path.exists(f + ".orig"):
        shutil.copy(f, f + ".orig")

# 1) Gradle wrapper of the engine: its Gradle version is known to work with its plugin versions.
for name in ("gradlew", "gradlew.bat"):
    src = os.path.join(eng, name)
    if os.path.exists(src):
        shutil.copy(src, os.path.join(proj, name))
w = os.path.join(eng, "gradle", "wrapper")
if os.path.isdir(w):
    os.makedirs(os.path.join(proj, "gradle", "wrapper"), exist_ok=True)
    for f in glob.glob(os.path.join(w, "*")):
        shutil.copy(f, os.path.join(proj, "gradle", "wrapper"))
    p = os.path.join(w, "gradle-wrapper.properties")
    if os.path.exists(p):
        m = re.search(r"distributionUrl=(\S+)", open(p).read())
        say("engine gradle:", m.group(1).split("/")[-1] if m else "?")
try:
    os.chmod(os.path.join(proj, "gradlew"), 0o755)
except Exception:
    pass

# 2) Plugin versions from the engine's version catalog.
tomls = sorted(glob.glob(os.path.join(eng, "gradle", "*.toml")))
toml = next((t for t in tomls if t.endswith("libs.versions.toml")), tomls[0] if tomls else None)
agp = kotlin = None
if toml and tomllib:
    d = tomllib.load(open(toml, "rb"))
    vers = d.get("versions", {})
    def ver(entry):
        v = entry.get("version")
        if isinstance(v, dict):
            v = v.get("ref") and vers.get(v["ref"]) or v.get("require") or v.get("strictly")
        if isinstance(v, str):
            return vers.get(v, v) if v in vers else v
        ref = entry.get("version.ref")
        return vers.get(ref) if ref else None
    for key, e in d.get("plugins", {}).items():
        pid = e.get("id", "") if isinstance(e, dict) else ""
        v = ver(e) if isinstance(e, dict) else None
        say("plugin", pid, v)
        if pid in ("com.android.library", "com.android.application") and v and not agp:
            agp = v
        if pid == "org.jetbrains.kotlin.android" and v and not kotlin:
            kotlin = v
else:
    say("no version catalog found" if not toml else "python has no tomllib")

# 2b) Our Compose plugin needs Kotlin 2.x. If the engine pins an older Kotlin, raise it in the engine's own catalog.
WANT_KOTLIN = "2.0.20"
if toml and kotlin and not kotlin.startswith(("2.", "3.")):
    txt = open(toml, encoding="utf-8").read()
    if '"%s"' % kotlin in txt:
        open(toml, "w", encoding="utf-8").write(txt.replace('"%s"' % kotlin, '"%s"' % WANT_KOTLIN))
        say("engine Kotlin", kotlin, "->", WANT_KOTLIN)
        kotlin = WANT_KOTLIN

# 2c) Gradle version: at least what the engine's wrapper says and what its AGP needs.
NEED = {"8.3": "8.4", "8.4": "8.6", "8.5": "8.7", "8.6": "8.7", "8.7": "8.9", "8.8": "8.10.2",
        "8.9": "8.11.1", "8.10": "8.11.1", "8.11": "8.13", "8.12": "8.13", "8.13": "8.13"}
def vt(x):
    return tuple(int(p) for p in re.findall(r"\d+", x)[:3])
wp = os.path.join(proj, "gradle", "wrapper", "gradle-wrapper.properties")
if agp and os.path.exists(wp):
    txt = open(wp).read()
    m = re.search(r"gradle-([\d.]+)-(bin|all)\.zip", txt)
    cur = m.group(1) if m else "0"
    need = NEED.get(".".join(agp.split(".")[:2]), cur)
    if vt(need) > vt(cur):
        txt = re.sub(r"gradle-[\d.]+-(bin|all)\.zip", "gradle-%s-bin.zip" % need, txt)
        open(wp, "w").write(txt)
        say("gradle raised", cur, "->", need)

# 3) Root plugin versions = the engine's, so both projects load the same plugin jars.
a = agp or "8.5.2"
k = kotlin or "2.0.20"
say("using AGP", a, "Kotlin", k)
open(root_b, "w").write(
    'plugins {\n'
    f'    id("com.android.application") version "{a}" apply false\n'
    f'    id("org.jetbrains.kotlin.android") version "{k}" apply false\n'
    f'    id("org.jetbrains.kotlin.plugin.compose") version "{k}" apply false\n'
    '}\n'
)
if not k.startswith(("2.", "3.")):
    say("WARNING: engine Kotlin is older than 2.0, the Compose plugin will not work with it")

# 4) compileSdk of the engine library must not be higher than ours.
mb = os.path.join(eng, "main", "build.gradle.kts")
if os.path.exists(mb):
    t = open(mb).read()
    m = re.search(r"compileSdk(?:Version)?\s*[=(]?\s*(?:release\()?(\d+)", t)
    if m:
        n = int(m.group(1))
        say("engine compileSdk", n)
        if n > 34:
            s = open(app_b).read().replace("compileSdk = 34", f"compileSdk = {n}")
            open(app_b, "w").write(s)
            say("app compileSdk raised to", n)
    m = re.search(r"ndkVersion\s*=?\s*\"([^\"]+)\"", t)
    if m:
        say("engine ndkVersion", m.group(1))
        open(os.path.join(proj, "ndk.txt"), "w").write(m.group(1))
    if "productFlavors" in t or "flavorDimensions" in t:
        for ln in t.splitlines():
            if re.search(r"flavor|dimension", ln, re.I):
                say("main:", ln.strip()[:110])
        pairs = re.findall(r"(?:create|register|getByName)\(\"(\w+)\"\)\s*\{[^{}]*?dimension\s*=\s*\"(\w+)\"", t, re.S)
        if not pairs:
            pairs = [(n, d) for d, n in re.findall(r"flavorDimensions[^\n]*\"(\w+)\"[\s\S]*?create\(\"(\w+)\"\)", t)][:1]
        if pairs:
            pref = ("skeleton", "ui")
            pick = next((p for w in pref for p in pairs if p[0] == w), pairs[0])
            s = open(app_b).read()
            if "missingDimensionStrategy" not in s:
                s = s.replace("targetSdk = 34", 'targetSdk = 34\n        missingDimensionStrategy("%s", "%s")' % (pick[1], pick[0]), 1)
                open(app_b, "w").write(s)
            say("flavor strategy", pick[1], pick[0], "of", pairs)
        else:
            say("flavors found but could not read them")
else:
    say("main/build.gradle.kts missing")
