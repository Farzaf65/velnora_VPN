pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Velnora"
include(":app")

// Optional OpenVPN engine: only when the build is started with -Pengine=on and the folder exists.
if (providers.gradleProperty("engine").orNull == "on" && file("ics-openvpn/main").exists()) {
    include(":ics-openvpn:main")
}
