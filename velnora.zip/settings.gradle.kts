pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Velnora"

// Optional OpenVPN engine: only when the build is started with -Pengine=on and the folder exists.
if (providers.gradleProperty("engine").orNull == "on" && file("ics-openvpn/main").exists()) {
    // The engine's own build files read versions from a catalog called "libVersions".
    val tomls = file("ics-openvpn/gradle").listFiles { f -> f.name.endsWith(".toml") }?.sortedBy { it.name } ?: emptyList()
    val toml = tomls.firstOrNull { it.name == "libs.versions.toml" } ?: tomls.firstOrNull()
    if (toml != null) {
        dependencyResolutionManagement {
            versionCatalogs {
                create("libVersions") { from(files(toml)) }
            }
        }
    }
    include(":ics-openvpn:main")
    // Our app is placed under the engine's parent project, so both share the same plugin classpath.
    include(":ics-openvpn:velnora")
    project(":ics-openvpn:velnora").projectDir = file("app")
} else {
    include(":app")
}
